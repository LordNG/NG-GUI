import j2me.ng.ui.paint.Paint;
import j2me.ng.ui.paint.Graphic;

public class Splash extends Paint{
    

    public Splash(){
        
    }

   public void Paint(Graphic g){
     g.drawGradient(0x55afff, 0x3f7fff, 0x4f9fff, 0, 0, W, H, Graphic.VERTICAL);
     
   }

}