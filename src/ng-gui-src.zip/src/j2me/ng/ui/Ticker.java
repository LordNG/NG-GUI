package j2me.ng.ui;

import j2me.ng.ui.paint.Graphic;
import j2me.ng.util.Utils;

public class Ticker extends Component{
    int tx;
    int sw;
    String string;

   public Ticker(String string){
      this.string = string;
      sw = Utils.pmfont.stringWidth(string);
      tx = 1;
   }

   public String getString(){
      return string;
   }

   public void paint(Graphic g){
      if(hasFocus){ Menu.centerS = "default";  focusl(g, x, y, width, height); }
      g.setColor(0x000000); g.setFont(Utils.pmfont);
      g.drawString(string, this.tx, y+2, Graphic.TOP|Graphic.LEFT);
      tx--;
      if((tx+10) == -sw) tx = W;
    }

    public int getPreferredWidth(){
       return 0;
    }

    public int getPreferredHeight() {
       return Utils.pmfh+4;
    }

}