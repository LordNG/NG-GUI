package j2me.ng.ui;

public interface KeyListener {
    public void keyAction(Key key, DeviceScreen devicescreen);
}