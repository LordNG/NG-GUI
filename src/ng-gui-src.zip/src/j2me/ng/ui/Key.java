package j2me.ng.ui;

public final class Key{
   public final static int
           KEY1 = 1, KEY2 = 2, KEY3 = 3, KEY4 = 4, KEY5 = 5, KEY6 = 6, KEY7 = 7, KEY8 = 8, KEY9 = 9, KEY0 = 10,
           CALL = 11, STAR = 12, POUND = 13;
   int type;

   public Key(int type){
     this.type = type;
   }

   public int getKeyType(){
     return type;
   }

}