package j2me.ng.ui;

import j2me.ng.ui.paint.Graphic;
import j2me.ng.ui.paint.Paint;

public abstract class Component extends Paint{
   public boolean hasFocus = false;
   public static boolean duplicationKeys = false;
   int x, y, width, height;

   public Component(){
   }

   public void paintComponent(Graphic g){
  //     if(hasFocus){ focus(g, x, y, width, height); }
     paint(g);
   }
   public abstract void paint(Graphic g);
   public abstract int getPreferredWidth();
   public abstract int getPreferredHeight();

   public boolean switchUp(){ return true; }
   public boolean switchDown(){ return true; }

   public boolean hasKey(){ return true; }

   public void focusGained(){ hasFocus = true; }
   public void focusLost(){ hasFocus = false; }

   public void onResize(){ }
   public void onClick(){ }

   public void keyPressed(int keyCode, int action){ }

    void focus(Graphic g, int x, int y, int width, int height){
      if(isDuplicationOfKeysOfNavigation() == false){
         g.RoundRectGradient(0x3f7fff, 0x2f5fff, 0x4f9fff, x+2, y+1, width-4, height-2, Graphic.VERTICAL);
         g.setColor(0x5599ff); g.drawRoundRect(x+2, y+1, width-5, height-3, 8, 8);
         g.setColor(0x0033ff); g.drawRoundRect(x+1, y, width-3, height-1, 8, 8);
      }
      if(isDuplicationOfKeysOfNavigation()){
         g.RoundRectGradient(0xff7f3f, 0xff5f2f, 0xff9f4f, x+2, y+1, width-4, height-2, Graphic.VERTICAL);
         g.setColor(0xff9955); g.drawRoundRect(x+2, y+1, width-5, height-3, 8, 8);
         g.setColor(0xff3300); g.drawRoundRect(x+1, y, width-3, height-1, 8, 8);
      }
    }

    void focusl(Graphic g, int x, int y, int width, int height){
       g.RoundRectGradient(0x8fbfff, 0x6fafff, 0x9fcfff, x+2, y+1, width-4, height-2, Graphic.VERTICAL);
       g.setColor(0xafdfff); g.drawRoundRect(x+2, y+1, width-5, height-3, 8, 8);
       g.setColor(0x8fafff); g.drawRoundRect(x+1, y, width-3, height-1, 8, 8);
    }

    public static void setDuplicationOfKeysOfNavigation(boolean flag){
        duplicationKeys = flag;
    }

    public static boolean isDuplicationOfKeysOfNavigation(){
        return duplicationKeys;
    }


}