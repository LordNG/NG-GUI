package j2me.ng.ui;

import j2me.ng.app.Application;
import j2me.ng.ui.paint.Graphic;
import j2me.ng.util.Utils;
import javax.microedition.lcdui.TextBox;
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.CommandListener;

public class TextField extends Component implements CommandListener{
    StringBuffer num;
    public static final int 
            ANY = 0,
            EMAILADDR = 1,
            NUMERIC = 2,
            PHONENUMBER = 3,
            URL = 4,
            DECIMAL = 5,
            PASSWORD = 65536;
    String title, string, charatX, charbeforeX;
    int type, max, len, h, caretX, caret = 0;
    TextBox t;
    Command c;

    public TextField(String title, String value){
       this.title = title;
       this.string = value;
       max = 5000;
       type = javax.microedition.lcdui.TextField.ANY;
       len = string.length();
    }

    public TextField(String title, String value, int max, int type){
       this.title = title;
       this.string = value;
       this.max = max;
       len = string.length();
       if(type == ANY){ this.type = javax.microedition.lcdui.TextField.ANY; }
       if(type == EMAILADDR){ this.type = javax.microedition.lcdui.TextField.EMAILADDR; }
       if(type == NUMERIC){
          this.type = javax.microedition.lcdui.TextField.NUMERIC;
          num = new StringBuffer(len);
          caretX = num.length();
       }
       if(type == PHONENUMBER){ this.type = javax.microedition.lcdui.TextField.PHONENUMBER; }
       if(type == URL){ this.type = javax.microedition.lcdui.TextField.URL; }
       if(type == DECIMAL){ this.type = javax.microedition.lcdui.TextField.DECIMAL; }
       if(type == PASSWORD){ this.type = javax.microedition.lcdui.TextField.PASSWORD; }
    }

    public void setCString(String content){
       this.string = content;
    }

    public String getString(){
       return string;
    }

    public void paint(Graphic g){
       if(hasFocus){ Menu.centerS = "Edit"; focus(g, x, y, width, height); }
       g.setFont(Utils.pmfont);
       g.drawGradient(0xdfdfdf, 0xeeeeee, 0xe2e2e2, x+10, y+Utils.pmfh+2, width-20, h+4, Graphic.VERTICAL);
       g.setColor(0x000000);
       g.drawString(title+":", x+10+2, y+2, Graphic.LEFT|Graphic.TOP);
       g.drawString(" "+leftInput(), x+width-10, y+2, Graphic.TOP|Graphic.RIGHT);
       g.drawRect(x+10, y+Utils.pmfh+2, width-20, h+4);
      if(type == PASSWORD){
         StringBuffer str = new StringBuffer(len);
         for(int i=0; i<len; i++) str.insert(i, '*');
         h = g.drawWrapString(str.toString(), x+10+2, y+Utils.pmfh+4, width-24);
         caret = Utils.pmfont.stringWidth(str.toString());
      }
      else if(type == NUMERIC){
         h = g.drawWrapString(num.toString(), x+10+2, y+Utils.pmfh+4, width-24);
         caret = Utils.pmfont.stringWidth(num.toString());
      }
      else{ h = g.drawWrapString(getString(), x+10+2, y+Utils.pmfh+4, width-24); caret = Utils.pmfont.stringWidth(string); }
     if(hasFocus){ g.setColor(0xff0000); g.drawLine(x+10+2+caret, y+Utils.pmfh+4, x+10+2+caret, y+Utils.pmfh+Utils.pmfh+2); }//caret
    }

    public int getPreferredWidth(){
       return Utils.pmfont.stringWidth(getString())+4;
    }

    public int getPreferredHeight(){
       return h+Utils.pmfh+10;
    }

    public int leftInput(){
      if(type == NUMERIC){ len = num.length(); }
      else{ len = string.length(); }
       return max-len;
    }

    public void onClick(){
      if(type == NUMERIC){
         Menu.showComponent(" ", "Ok", "Clear");
         duplicationKeys = !duplicationKeys;
      }
      else{
        t = new TextBox(title, getString(), max, type);
        c = new Command("OK",Command.OK,1);
        t.addCommand(c);
        t.setCommandListener(this);
        Application.application.setView(t);
      }
    }

   public void keyPressed(int key, int action){
    if(duplicationKeys){
      if(key == Dup_SOFT_RIGHT){ clear(); }
      if(key == LEFT){ caretX = caretX-1; if(caretX <= 0) caretX = 0; }
      if(key == RIGHT){ caretX = caretX+1; if(caretX >= len) caretX = len; }
      if(key == KEY_NUM1){ insert(1); }
      if(key == KEY_NUM2){ insert(2); }
      if(key == KEY_NUM3){ insert(3); }
      if(key == KEY_NUM4){ insert(4); }
      if(key == KEY_NUM5){ insert(5); }
      if(key == KEY_NUM6){ insert(6); }
      if(key == KEY_NUM7){ insert(7); }
      if(key == KEY_NUM8){ insert(8); }
      if(key == KEY_NUM9){ insert(9); }
      if(key == KEY_NUM0){ insert(0); }
    }
   }

   void insert(int input){
     if(leftInput() > 0){
       num.insert(caretX, input);
       caretX = caretX+1;
     }
   }
   void clear(){
     if(caretX > 0){
       num.deleteCharAt(caretX-1);
       caretX = caretX-1;
     }
   }

    public void commandAction(Command c, Displayable d){
       if(c == this.c){
          setCString(t.getString());
          Application.application.setPreviousView();
          t = null;
          System.gc();
       }
    }


}