package j2me.ng.ui;

import j2me.ng.ui.paint.Graphic;
import j2me.ng.util.Utils;

public class Button extends Component{
   public int buttonW, part, current = 1, max;
   public String Label, Label2, Label3, str = " ";
   public static int PART = 0, PART2 = 1, PART3 = 2;

   public Button(String label){
     Label = label;
     part = PART;
     buttonW = W-20;
     max = 1;
   }

   public Button(String label, String label2){
     Label = label;
     Label2 = label2;
     part = PART2;
     buttonW = (W/2)-10;
     max = 2;
   }

   public Button(String label, String label2, String label3){
      Label = label;
      Label2 = label2;
      Label3 = label3;
      part = PART3;
      buttonW = (W/3)-10;
      max = 3;
   }

    public void paint(Graphic g){
      if(hasFocus){
        Menu.centerS = "Press"; 
        if(current == 1) focus(g, x+10-4, y, buttonW+7, Utils.pmfh+10+4);
        if(current == 2) focus(g, x+10-4+buttonW+4, y, buttonW+7, Utils.pmfh+10+4);
        if(current == 3) focus(g, x+10-4+((buttonW+4)*2), y, buttonW+7, Utils.pmfh+10+4);
      }
         g.setFont(Utils.pmfont);
       if(part == PART){
          g.setColor(0xbb0000);
          g.fillRoundRect(x+10, y+2, buttonW, Utils.pmfh+10, 8, 8);
          g.setColor(0xff0000);
          g.fillRoundRect(x+11, y+3, buttonW-2, Utils.pmfh+10-2, 8, 8);
          g.setColor(0xffffff); g.drawString(Label, x+10+(buttonW/2), y+5, Graphic.TOP|Graphic.HCENTER);
       }
       if(part == PART2){
          g.setColor(0xff0000);
          g.fillRoundRect(x+10, y+2, buttonW, Utils.pmfh+10, 8, 8);
          g.fillRoundRect(x+10+buttonW+4, y+2, buttonW, Utils.pmfh+10, 8, 8);
          g.setColor(0xffffff);
          g.drawString(Label, x+10+(buttonW/2), y+5, Graphic.TOP|Graphic.HCENTER);
          g.drawString(Label2, x+10+buttonW+4+(buttonW/2), y+5, Graphic.TOP|Graphic.HCENTER);
       }
       if(part == PART3){
          g.setColor(0xff0000);
          g.fillRoundRect(x+10, y+2, buttonW, Utils.pmfh+10, 8, 8);
          g.fillRoundRect(x+10+buttonW+4, y+2, buttonW, Utils.pmfh+10, 8, 8);
          g.fillRoundRect(x+10+((buttonW+4)*2), y+2, buttonW, Utils.pmfh+10, 8, 8);
          g.setColor(0xffffff);
          g.drawString(Label, x+10+(buttonW/2), y+5, Graphic.TOP|Graphic.HCENTER);
          g.drawString(Label2, x+10+buttonW+4+(buttonW/2), y+5, Graphic.TOP|Graphic.HCENTER);
          g.drawString(Label3, x+10+((buttonW+4)*2)+(buttonW/2), y+5, Graphic.TOP|Graphic.HCENTER);
       }
      g.drawString(str, W/2, y+5, Graphic.TOP|Graphic.HCENTER);
    }

    public int getPreferredWidth(){ return 0; }

    public int getPreferredHeight(){
       return Utils.pmfh+10+5;
    }

    public String getPressedButton(){
       String pb = null;
        if(current == 1) pb = Label;
        if(current == 2) pb = Label2;
        if(current == 3) pb = Label3;
      return pb;
    }
    public int getSelectedButton(){
       return current;
    }

    public void onClick(){
    //   Menu.showComponent(" ", "Select", "Cancel");
   //    duplicationKeys = !duplicationKeys;
    }

   public void keyPressed(int key, int action){
  //  if(duplicationKeys){
       if(key == LEFT){ current = current-1; if(current < 1) current = max; }
       if(key == RIGHT){ current = current+1; if(current > max) current = 1; }
       if(key == UP){ current = current-1; if(current < 1) current = max; }
       if(key == DOWN){ current = current+1; if(current > max) current = 1; }
  //  }
   }

}