package j2me.ng.ui;

import j2me.ng.ui.paint.Graphic;

public class Space extends Component{
   int widt, heigh;

   public Space(int w, int h){
     widt = w;
     heigh = h;
   }

   public void paint(Graphic g){
      if(hasFocus){ Menu.centerS = "default"; }
   }

   public int getPreferredWidth(){ return widt;  }
   public int getPreferredHeight(){ return heigh; }

}