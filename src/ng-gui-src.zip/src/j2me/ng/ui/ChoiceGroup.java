package j2me.ng.ui;

import j2me.ng.ui.paint.Graphic;

public class ChoiceGroup extends Component{

    public void paint(Graphic g) {
    }

    public int getPreferredWidth(){
        return 0;
    }

    public int getPreferredHeight(){
        return 0;
    }

    public void onClick(){
       duplicationKeys = !duplicationKeys;
    }

}