package j2me.ng.ui;

import j2me.ng.util.*;
import j2me.ng.ui.paint.*;

public class Menu extends Paint{
    public static String
           leftS = " ", rightS = " ", centerS = " ",
           leftc = " ", rightc = " ", centerc = " ",
           leftp = " ", rightp = " ", centerp = " ";
    public static boolean compKey = false;
    public static final int STATE_NORMAL = 1, STATE_MENU = 2, STATE_POPUP = 3;
    public Godawn cmdl, cmdc, cmdr,
            call, key0, star, pound;
    public int cmdLen, menuFocus, menuX, menuY, menuW, menuH, menuBarH;
    private String cen = " ";

    public Menu(){
       currentMode = STATE_NORMAL;
       menuBarH = Utils.psfh+2;
       cmdLen = 0;
       cmdl = new Godawn(); cmdc = new Godawn(); cmdr = new Godawn();
       call = new Godawn(); key0 = new Godawn(); star = new Godawn(); pound = new Godawn();
    }

    public void addCommand(Command cmd){
      if(cmd.getCommandType() == Command.MENU){ cmdl.addElement(cmd); }
      else if(cmd.getCommandType() == Command.OK){ cmdc.addElement(cmd); }
      else if(cmd.getCommandType() == Command.EXIT){ cmdr.addElement(cmd); }
      else if(cmd.getCommandType() == Command.ITEM){
        if(cmdl != null ){ cmdl.addElement(cmd); }
      }
      update();
    }

    public void addKey(Key key){
      if(key.getKeyType() == Key.CALL){ call.addElement(key); }
      if(key.getKeyType() == Key.KEY0){ key0.addElement(key); }
      if(key.getKeyType() == Key.STAR){ star.addElement(key); }
      if(key.getKeyType() == Key.POUND){ pound.addElement(key); }
    }

    public void update(){
      refreshCommand();
      if(cmdl != null ){ cmdLen = cmdl.length(); }
      else{ cmdLen = 0; }
       menuX = 2;
       menuW = 100;
       menuH = 4+(cmdLen)*(Utils.psfh);
       menuY = getHeight()-menuBarH-menuH-2;
      repaint();
    }

    void refreshCommand(){
      if(cmdl != null && cmdl.length() >= 1){
         if(cmdLen <= 1){ Command uic = ((Command)cmdl.elementAt(0)); leftS = uic.getLabel(); }
         if(cmdLen > 1){ leftS = "Menu"; }
      } else{ leftS = " "; }
      if(cmdc != null && cmdc.length() == 1){ Command uic = (Command)cmdc.elementAt(0); cen = centerS = uic.getLabel(); } else{ centerS = " "; }
      if(cmdr != null && cmdr.length() == 1){ Command uic = (Command)cmdr.elementAt(0); rightS = uic.getLabel(); } else{ rightS = " "; }
    }

    public void showMenu(boolean bShow){
       if(bShow){ currentMode = STATE_MENU; }
       else{ currentMode = STATE_NORMAL; menuFocus = 0; }
    }

    public static void showComponent(String a, String b, String c){
       leftc = a; centerc = b; rightc = c;
       compKey =! compKey;
    }

    public void showPopup(String a, String b, String c, boolean bShow){
       if(bShow){
          leftp = a; centerp = b; rightp = c;
          currentMode = STATE_POPUP;
       }
       else{ currentMode = STATE_NORMAL; }
    }

    public void drawMenu(Graphic g){
      if(centerS.equals("default")){ centerS = cen; } 
      softbar(g, leftS, centerS, rightS);
      if(compKey){ softbar(g, leftc, centerc, rightc); }
      if(currentMode == STATE_POPUP){ softbar(g, leftp, centerp, rightp); }
      g.setFont(Utils.psfont);
      if(currentMode == STATE_MENU){
        g.drawPhoto(Photo.createTransparentPhoto(W, H-menuBarH, 0x44000000), 0, 0, 0);
        g.drawPhoto(Photo.createTransparentPhoto(menuW+1, menuH, 0xaaffffff), menuX, menuY, 0);

        g.RectShadow(menuX, menuY, menuW+1, menuH, 0x1f000000, 5);

        g.setColor (0x000000); g.drawRect (menuX, menuY, menuW+1, menuH);
        int y = menuY+2; g.setColor(0);
        for(int i=0; i<cmdLen; i++){
            g.drawString( ((Command)cmdl.elementAt(i)).getLabel() , menuX+4, y, Graphic.LEFT|Graphic.TOP);
            y += Utils.psfh+1;
        }
        g.drawGradient(0x2f2f2f, 0x1f1f1f, 0x2f2f2f, menuX+2, menuY+2+(Utils.psfh*menuFocus), menuW-2, Utils.psfh, Graphic.VERTICAL);
        g.setColor(0xffffff); g.drawString(getSelectedCommand(), menuX+4, menuY+2+(Utils.psfh*menuFocus), Graphic.LEFT|Graphic.TOP);
        softbar(g, " ", "Select", "Cancel");
      }
    }

    void softbar(Graphic g, String a, String b, String c){
      g.setFont(Utils.psfont); g.drawSoftbar(a, b, c, W, H, Graphic.BOTTOM);
    }

    public String getSelectedCommand(){ return ((Command)cmdl.elementAt(menuFocus)).getLabel(); }

    public int getSelectedCommandIndex(){ return menuFocus; }

}