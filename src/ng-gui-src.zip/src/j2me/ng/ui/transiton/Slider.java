package j2me.ng.ui.transiton;

import j2me.ng.ui.paint.Graphic;
import j2me.ng.ui.paint.Paint;
import javax.microedition.lcdui.Display;

public class Slider extends Paint{
   public static int UPLEFT=1, UP=2, UPRIGHT=3, LEFT=4, RIGHT=6, DOWNLEFT=7, DOWN=8, DOWNRIGHT=9;
   Paint fromCanvas = null, toCanvas = null;
   Display display = null;
   int deltaX = 0, deltaY = 0, direction = LEFT;
   long startTime, duration;

   public Slider(Display display, Paint toCanvas){
      this.display = display;
      this.fromCanvas = (Paint)display.getCurrent();
      this.toCanvas = toCanvas;
      startTime = System.currentTimeMillis();
   }

   public Slider(Display display, Paint toCanvas, int direction, long duration){
      this(display, toCanvas);
       this.direction = direction;
        if(direction == UPLEFT){ deltaX = -W; deltaY = -H; }
        if(direction == UP){ deltaY = -H; }
        if(direction == UPRIGHT){ deltaX = W; deltaY = -H; }
        if(direction == LEFT){ deltaX = -W; }
        if(direction == RIGHT){ deltaX = W; }
        if(direction == DOWNLEFT){ deltaX = -W; deltaY = H; }
        if(direction == DOWN){ deltaY = H; }
        if(direction == DOWNRIGHT){ deltaX = W; deltaY = H; }
       this.duration = duration;
   }

   public void setSlideDirction(int direction){ this.direction = direction; }
   public void setSlideDuration(long duration){ this.duration = duration; }

   public void Paint(Graphic g){
      long diff = System.currentTimeMillis() - startTime;
      int perc = (int)(100 * diff / duration);
      int dx = deltaX * perc / 100;
      int dy = deltaY * perc / 100;
      g.translate(dx, dy);
      fromCanvas.Paint(g);
      g.translate(- deltaX, - deltaY);
      toCanvas.Paint(g);
      g.translate(deltaX - dx, deltaY - dy);
      if(diff < duration){ repaint(); }
      if(diff >= duration){ display.setCurrent(toCanvas); }
   }

}