package j2me.ng.ui;

import j2me.ng.ui.paint.Graphic;
import j2me.ng.ui.paint.Paint;
import j2me.ng.util.Utils;

public class Popup{
   public static String content = "", popupT = " ", menul = " ", menuc = "Ok", menur = "Cancel";

   public Popup(String label, String string){ popupT = label; content = string; }
   public void addMenuL(String menu){ menul = menu; }
  // public void addMenuC(String menu){ menuc = menu; }
   public void addMenuR(String menu){ menur = menu; }
   public void setString(String string){ content = string; }

   public String getTitle(){ return popupT; }
   public String getString(){ return content; }
   public String getMenuL(){ return menul; }
   public String getMenuC(){ return menuc; }
   public String getMenuR(){ return menur; }

   public void popup(Graphic g, int x, int y, int W, int H){
      g.drawPhoto(Photo.createTransparentPhoto(W, H-Utils.psfh+1, 0x44000000), 0, 0, 0);
      g.RoundRectGradient(0x444444, 0x555555, 0x333333, x, y, W-(x*2), H-(y*2), Graphic.VERTICAL);
      g.RoundRectGradient(0xeeeeee, 0xdddddd, x+2, y+2, W-((x*2)+2), Utils.pmfh+2, Graphic.VERTICAL);
      g.setColor(0x222222);
      g.setFont(Utils.pmfont); g.drawString(getTitle(), W/2, y+3, Graphic.HCENTER|Graphic.TOP);
      g.drawRoundRect(x, y, W-((x*2)-1), H-((y*2)-1), 8, 8);
      g.setColor(0xeeeeee); g.setFont(Utils.bsfont); g.drawWrapString(getString(), x+5, y+(x*2)+5, W-((x*2)+10));
      g.setColor(0x666666); g.drawRoundRect(x+1, y+1, W-((x*2)+1), H-((y*2)+1), 8, 8);
      g.drawLine(x, y+Utils.pmfh+2+4, W-(x), y+Utils.pmfh+2+4);
 //     g.drawLine(x+1, y+Paint.pmfh+2+2, W-(x+1), y+Paint.pmfh+2+2); g.drawLine(x+1, y+Paint.pmfh+2+4, W-(x+1), y+Paint.pmfh+2+4);
 //     g.setColor(0x222222); g.drawLine(x, y+Paint.pmfh+2+3, W-(x), y+Paint.pmfh+2+3);
   }

}