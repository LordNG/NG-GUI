package j2me.ng.ui.parser;

 public class Tag{
   public final String
            IComma = ""+(char)34,
            Comma = ",",
            StartTag = "<",
            EndTag = ">",
            Equal = "=",
            SComma = ";",
            Slash = "/",
            Excla = "!",
            Space = " ",
            StartB = "(",
            EndB = ")",
            Comment = "//";

   public static String str(char ch){
      String val = String.valueOf(ch);
      return val;
   }
/*
(char)33 = !
(char)34 = "
(char)35 = #
(char)36 = $
(char)37 = %
(char)38 = &
(char)39 = '
(char)40 = (
(char)41 = )
(char)42 = *
(char)43 = +
(char)44 = ,
(char)45 = -
(char)46 = .
(char)47 = /
(char)48 = 0
(char)49 = 1
(char)50 = 2
(char)51 = 3
(char)52 = 4
(char)53 = 5
(char)54 = 6
(char)55 = 7
(char)56 = 8
(char)57 = 9
(char)58 = :
(char)59 = ;
(char)60 = <
(char)61 = =
(char)62 = >
(char)63 = ?
(char)64 = @
(char)65 = A
(char)66 = B
(char)67 = C
(char)68 = D
(char)69 = E
(char)70 = F
(char)71 = G
(char)72 = H
(char)73 = I
(char)74 = J
(char)75 = K
(char)76 = L
(char)77 = M
(char)78 = N
(char)79 = O
(char)80 = P
(char)81 = Q
(char)82 = R
(char)83 = S
(char)84 = T
(char)85 = U
(char)86 = V
(char)87 = W
(char)88 = X
(char)89 = Y
(char)90 = Z
(char)91 = [
(char)92 = \
(char)93 = ]
(char)94 = ^
(char)95 = _
(char)96 = `
(char)97 = a
(char)98 = b
(char)99 = c
(char)100 = d
(char)101 = e
(char)102 = f
(char)103 = g
(char)104 = h
(char)105 = i
(char)106 = j
(char)107 = k
(char)108 = l
(char)109 = m
(char)110 = n
(char)111 = o
(char)112 = p
(char)113 = q
(char)114 = r
(char)115 = s
(char)116 = t
(char)117 = u
(char)118 = v
(char)119 = w
(char)120 = x
(char)121 = y
(char)122 = z
(char)123 = {
(char)124 = |
(char)125 = }
(char)126 = ~
*/

}