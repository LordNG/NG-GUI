package j2me.ng.ui.parser;

import j2me.ng.util.StringUtil;

 public class XML extends Tag{
   public String name, OriginalTAG, TAG;

   public void setParser(String text){
      OriginalTAG = text;
      TAG = text;
    }

   public void resetParser(){
      setParser(OriginalTAG);
   }

   public void EnterSection(String tag){
         int tagIndex = TAG.indexOf(StartTag+tag+EndTag);
         int endIndex = TAG.indexOf(StartTag+Slash+tag+EndTag, tagIndex);
         TAG = TAG.substring(tagIndex, endIndex);
   }

//String
  //for value of <TAG>Value</TAG>
    public String getString(String tag){
         int tagIndex = TAG.indexOf(StartTag+tag);
         tagIndex = TAG.indexOf(EndTag, tagIndex);
         int endIndex = TAG.indexOf(StartTag+Slash+tag+EndTag, tagIndex);
        String prs = TAG.substring(tagIndex + 1, endIndex);
        return prs;
    }
  //for value of <TAG="Value"/>
    public String getStringV(String tag){
         int tagIndex = TAG.indexOf(StartTag+tag+Equal);
         tagIndex = TAG.indexOf(IComma, tagIndex);
         int endIndex = TAG.indexOf(IComma+Slash+EndTag, tagIndex);
        String prs = TAG.substring(tagIndex + 1, endIndex);
        return prs;
    }
  //for value of <TAG Value="value">
    public String getString(String tag, String val){
      int tagIndex = TAG.indexOf(StartTag+tag+Space+val+Equal);
      tagIndex = TAG.indexOf(IComma, tagIndex);
      int endIndex = TAG.indexOf(IComma+Space, tagIndex);
      String prs = TAG.substring(tagIndex + 1, endIndex);
        return prs;
    }
//End String

//Integer
  //for value of <TAG>1234</TAG>
   public int getInt(String tag){
      int a = 0;
     a = Integer.parseInt(getString(tag));
       return a;
   }
  //for value of <TAG Value="0">
   public int getInt(String tag, String val){
      int prs = 0;
      int tagIndex = TAG.indexOf(StartTag+tag+Space+val+Equal);
      tagIndex = TAG.indexOf(IComma, tagIndex);
      int endIndex = TAG.indexOf(IComma+Space, tagIndex);
      String tv = TAG.substring(tagIndex + 1, endIndex);
        prs = Integer.parseInt(tv);
        return prs;
   }
  //for values of <TAG Value="0,0,0,0">
   public int getInt(String tag, String val, int token){
      String tv = "0,0,0,0";
      int prs = 0;
      int tagIndex = TAG.indexOf(StartTag+tag+Space+val+Equal);
      tagIndex = TAG.indexOf(IComma, tagIndex);
      int endIndex = TAG.indexOf(IComma+EndTag, tagIndex);
      tv = TAG.substring(tagIndex + 1, endIndex);
   String[] sb = StringUtil.split(tv, Comma);
     if(token == 0){
        prs = Integer.parseInt(tv); }
     if(token == 1){
        prs = Integer.parseInt(sb[0]); }
     if(token == 2){
        prs = Integer.parseInt(sb[1]); }
     if(token == 3){
        prs = Integer.parseInt(sb[2]); }
     if(token == 4){
        prs = Integer.parseInt(sb[3]); }
        return prs;
   }
  //for value of <TAG="1234"/>
   public int getIntV(String tag){
     int a = 0;
     a = Integer.parseInt(getStringV(tag));
     return a;
   }
  //for values of <TAG="0,0,0,0">
   public int getInt(String tag, char seperator, int token){
     String tv = "0"+seperator+"0"+seperator+"0"+seperator+"0";
     tv = getStringV(tag);
     int prs = 0;
     String[] sb = StringUtil.split(tv, seperator);
      if(token == 0){ prs = Integer.parseInt(tv); }
      if(token == 1){ prs = Integer.parseInt(sb[0]); }
      if(token == 2){ prs = Integer.parseInt(sb[1]); }
      if(token == 3){ prs = Integer.parseInt(sb[2]); }
      if(token == 4){ prs = Integer.parseInt(sb[3]); }
        return prs;
   }
//End Integer

//Color
  //for value of <TAG>0x000000</TAG>
    public int getIntcolor(String tag){
     String ctag = getString(tag);
     int rgb = 0;
     if(ctag.length() == 6){
       String st = ctag.substring(0, 6);
       rgb = Integer.parseInt(st,16); }
     else if(ctag.length() == 7){
       String st = ctag.substring(1, 7);
       rgb = Integer.parseInt(st,16); }
    else if(ctag.length() == 8){
       String st = ctag.substring(2, 8);
       rgb = Integer.parseInt(st,16); }
       return rgb;
    }
  //for value of <TAG="0x000000"/>
    public int getIntColor(String tag){
     String ctag = getStringV(tag);
     int rgb = 0;
     if(ctag.length() == 6){
       String st = ctag.substring(0, 6);
       rgb = Integer.parseInt(st,16); }
     else if(ctag.length() == 7){
       String st = ctag.substring(1, 7);
       rgb = Integer.parseInt(st,16); }
    else if(ctag.length() == 8){
       String st = ctag.substring(2, 8);
       rgb = Integer.parseInt(st,16); }
    else if(ctag.length() == 10){
       String st = ctag.substring(2, 10);
       rgb = Integer.parseInt(st,16); }
       return rgb;
    }
  //returns color 123456 from int 0x123456
    public int intTOcolor(String tag){
     int rgb = 0;
     if(tag.length() == 6){
       String st = tag.substring(0, 6);
       rgb = Integer.parseInt(st,16); }
     else if(tag.length() == 7){
       String st = tag.substring(1, 7);
       rgb = Integer.parseInt(st,16); }
    else if(tag.length() == 8){
       String st = tag.substring(2, 8);
       rgb = Integer.parseInt(st,16); }
       return rgb;
    }
//End Color

//boolean
  //for boolean of <TAG>true</TAG>
   public boolean getBoolean(String tag){
      boolean bool = false;
      int tagIndex = TAG.indexOf(StartTag+tag);
      tagIndex = TAG.indexOf(EndTag, tagIndex);
      int endIndex = TAG.indexOf(StartTag+Slash+tag+EndTag, tagIndex);
      String prs = TAG.substring(tagIndex + 1, endIndex);
      if("true".equals(prs)){ bool = true;}
      if("false".equals(prs)){ bool = false;}
       return bool;
   }
  //for boolean of <TAG Value="false">
    public boolean getBoolean(String tag, String val){
      boolean bool = false;
      int tagIndex = TAG.indexOf(StartTag+tag+Space+val+Equal);
      tagIndex = TAG.indexOf(IComma, tagIndex);
      int endIndex = TAG.indexOf(IComma+Space, tagIndex);
      String prs = TAG.substring(tagIndex + 1, endIndex);
      if("true".equals(prs)){ bool = true; }
      if("false".equals(prs)){ bool = false; }
        return bool;
    }
//End boolean

}