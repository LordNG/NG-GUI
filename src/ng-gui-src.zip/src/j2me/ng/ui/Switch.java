package j2me.ng.ui;

import j2me.ng.ui.paint.Graphic;
import j2me.ng.util.Utils;

public class Switch extends Component{
   boolean on = false;
   String s;

    public Switch(String s){ this.s = s; }

    public Switch(String s, boolean checked){
        this.s = s;
        this.on = checked;
    }

    public void paint(Graphic g){
      if(hasFocus){
        if(on){ Menu.centerS = "Off"; }
        if(!on){ Menu.centerS = "On"; }
        focus(g, x, y, width, height);
      }
       g.setColor(0xffffff); g.fillRoundRect(x+3, y+2, 30, 20, 8, 8);
       g.setColor(0xbbbbbb); g.fillRoundRect(x+4, y+3, 28, 18, 8, 8);
       if(on){ g.setColor(0xffffff); g.fillRoundRect(x+5, y+4, (30/2)-3, 20-4, 8, 8); }
       if(!on){ g.setColor(0x4f4f4f); g.fillRoundRect(x+(30/2)+4, y+4, (30/2)-3, 20-4, 8, 8); }
    //   g.setColor(0xffffff); g.fillRect(x+(30/3)+3, y+2, 10-1, 20);
       g.drawGradient(0xeeeeee, 0xffffff, 0xeeeeee, x+(30/3)+3+1, y+2, 10-2, 20, Graphic.HORIZONTAL);
 //      g.setColor(0xffffff); g.drawRoundRect(x+3, y+2, 30-1, 20-1, 8, 8);
       g.setColor(0xcfcfcf);
       g.drawLine(x+(30/3)+3+3, y+5, x+(30/3)+3+3, y+16);
       g.drawLine(x+(30/3)+3+5, y+4, x+(30/3)+3+5, y+18);
       g.drawLine(x+(30/3)+3+7, y+5, x+(30/3)+3+7, y+16);
       g.setColor(0x000000); g.setFont(Utils.pmfont); g.drawString(s, x+30+10, y+2, Graphic.LEFT | Graphic.TOP);
       g.setColor(0xffffff); g.drawRoundRect(x+3, y+2, 30-1, 20-1, 8, 8);
    }

    public int getPreferredWidth(){ return Utils.pmfont.stringWidth(s)+4; }
    public int getPreferredHeight(){ return Utils.pmfh+8; }
    public void onClick(){ on = !on; }
    public boolean isSwiched(){ return on; }

}