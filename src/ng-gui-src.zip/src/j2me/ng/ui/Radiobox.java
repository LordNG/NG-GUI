package j2me.ng.ui;

import j2me.ng.ui.paint.Graphic;
import j2me.ng.util.Utils;
import java.io.IOException;
import javax.microedition.lcdui.Image;

public class Radiobox extends Component{
    public boolean checked = false;
    Image radiobox, radioboxs, img = null;
    String s, data[];
    Checkbox cb;

    void r(){
       try{
         radiobox = Image.createImage("/res/rb1.png");
         radioboxs = Image.createImage("/res/rb2.png"); }
       catch(IOException ex){ Errors.error("Unable to load image.", ex.toString(), true); }
    }

    public Radiobox(String s, String data[]){
        this.s = s;
        this.data = data;
        r();
       for(int i=- 0; i<data.length; i++){
         cb = new Checkbox(data[i]);
       }
    }

    public int getPreferredWidth(){ return 0; }

    public int getPreferredHeight(){
        return (data.length*Utils.pmfh)+5;
    }

    public void paint(Graphic g){ }

}