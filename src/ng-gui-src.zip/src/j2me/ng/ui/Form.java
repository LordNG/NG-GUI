package j2me.ng.ui;

import j2me.ng.ui.paint.*;

public class Form extends DeviceScreen{
   int formHeight = H;

   public Form(String titles){
       title = titles;
   }

   public void append(String string){
      Text strings = new Text(string);
      if(string != null){
        if(!components.contains(strings)){ components.addElement(strings); }
      }
   }

   public void append(Component component){
      if(component != null){
         if(!components.contains(component)){ components.addElement(component); }
       }
   }

   public void append(javax.microedition.lcdui.Image image){
      photo = new Photo(image);
      if(photo != null){
         if(!components.contains(photo)){ components.addElement(photo); }
       }
   }

    void paintScreen(Graphic g){
       g.translate(0, -curY);
       for(int i=0; i<components.size(); i++){
          Component e = ((Component)components.elementAt(i));
          g.setClip(e.x, e.y, e.width, e.height);
          e.paintComponent(g);
      //    formHeight = cury;
       }
       g.translate(0, curY);
       g.setClip(0, 0, getWidth(), getHeight());
   }

   public int formWidth(){ return W; }
   public int formHeight(){ return formHeight; }

   void realpaint(Graphic g){
     I = Photo.createPhoto(W, H);
     Graphic G = I.getGraphic();
     drawBackground(G);
     if(components.size() >= 0){ paintScreen(G); }
     g.drawPhoto(I, 0, 0, 0);
   }

   public void Paint(Graphic g){
      realpaint(g);
      drawFrame(g);
      appendLayout(); refocus();
      PaintSS(g);
      if(currentMode == STATE_POPUP){ popup.popup(g, 10, 30, W, H); }
      repaint();
   }
/*
    public void keyPressed(int key){
       int ke = getKey(key);
       System.out.println("KEY: "+key+", getKey("+ke+")");
//Menu
       if(currentMode == STATE_MENU){
          if(ke == SOFT_RIGHT){ showMenu(false); }
          else if(ke == RIGHT){
          if(commandListener != null) commandListener.commandAction((Command)cmdl.elementAt(menuFocus), this);
             showMenu(false);
          }
          else if(ke == UP){
              menuFocus--;
              if(menuFocus < 0) menuFocus = cmdl.length()-1;
          }
          else if(ke == DOWN){
              menuFocus++;
              if(menuFocus >= cmdl.length()) menuFocus = 0;
          }
          else if(ke == CENTER){
              if(commandListener != null) commandListener.commandAction((Command)cmdl.elementAt(menuFocus), this);
              showMenu(false);
          }
       }
//Menu > Main
       else if(currentMode == STATE_NORMAL){
         if(Component.isDuplicationOfKeysOfNavigation() == false){//Duplicate keys
          if(ke == SOFT_LEFT){//if(key == SOFT_LEFT)
             if(!cmdl.isEmpty()){
               if(cmdl.length() >= 1){ showMenu (true); }
               else{ commandListener.commandAction((Command)cmdl.elementAt(0), this); }
             }
             else{ }
          }
          else if(ke == CENTER){
             if(!cmdc.isEmpty()){ commandListener.commandAction((Command)cmdc.elementAt(0), this); }
             else{ }
          }
          else if(ke == SOFT_RIGHT){
              if(!cmdr.isEmpty()){ commandListener.commandAction((Command)cmdr.elementAt(0), this); }
              else{ }
          }
        }//Duplicate keys
   //Component
          if(components != null){
            selection.keyPressed(ke, getGameAction(key));
            if(ke == CENTER){ selection.onClick(); }
            if(Component.isDuplicationOfKeysOfNavigation() == false){//Duplicate keys
              if(ke == DOWN){ focusDown(); }
              if(ke == UP){ focusUp(); }
            }//Duplicate keys
          }
  //Component 
       }
//Main > Popup
       else if(currentMode == STATE_POPUP){
          if(ke == SOFT_LEFT){ }
          else if(ke == CENTER){ }
          else if(ke == SOFT_RIGHT){ showPopup(false); }
       }
//Popup
//Key - KeyListener
       if(ke == CALL){ if(!call.isEmpty()){ keyListener.keyAction((Key)call.elementAt(0), this); } else{ } }
       if(ke == KEY_NUM0){ if(!key0.isEmpty()){ keyListener.keyAction((Key)key0.elementAt(0), this); } else{ } }
       if(ke == KEY_STAR){ if(!star.isEmpty()){ keyListener.keyAction((Key)star.elementAt(0), this); } else{ } }
       if(ke == KEY_POUND){ if(!pound.isEmpty()){ keyListener.keyAction((Key)pound.elementAt(0), this); } else{ } }
//Key - KeyListener
    }*/
    public void keyPressed(int key) {
       int ke = getKey(key);
       System.out.println("KEY: "+key+", getKey("+ke+")");
       if(Component.isDuplicationOfKeysOfNavigation() == false){ keyCommon(ke); }//Duplicate keys
       if(currentMode == STATE_NORMAL){
   //Component
          if(components != null){
            selection.keyPressed(ke, getGameAction(key));
            if(ke == CENTER){ selection.onClick(); }
            if(Component.isDuplicationOfKeysOfNavigation() == false){//Duplicate keys
              if(ke == DOWN){ focusDown(); }
              if(ke == UP){ focusUp(); }
            }//Duplicate keys
          }
  //Component 
       }
    }
    public void keyRepeated(int key){ keyPressed(key); }
    public void keyReleased(int key){ }


}