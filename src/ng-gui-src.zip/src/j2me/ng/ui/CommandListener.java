package j2me.ng.ui;

public interface CommandListener {
    public void commandAction(Command command, DeviceScreen devicescreen);
}