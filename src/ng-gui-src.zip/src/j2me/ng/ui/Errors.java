package j2me.ng.ui;

public class Errors{
   private static String stre, strm;
   public static boolean err;

    public static final void error(String strmg, String strer, boolean errv){
      stre = strer;
      strm = strmg;
      err = errv;
    }

    public static boolean get(){ return err; }

    public static String getError(){ return stre; }

    public static String getMessage(){ return strm; }

}