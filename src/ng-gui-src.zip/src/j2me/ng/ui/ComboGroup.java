package j2me.ng.ui;

import j2me.ng.ui.paint.Graphic;
import j2me.ng.util.Utils;

public class ComboGroup extends Component{
    private String coData[], title;
    private int currentSel, dataLen, CursorY,  printList, cursorH, ch;
    private int listY;
    private boolean ss = false;

    public ComboGroup(String title, String string[]){
       CursorY = currentSel = 0;
       printList = 0;
       this.title = title;
       coData = string;
       dataLen = string.length;
       cursorH = Utils.pmfh+4;
       ch = (cursorH+2)*2;
       listY = CursorY = printList = currentSel = 0;
    }

   public String getSelected(){ return coData[currentSel]; }
   public int getSelectedIndex(){ return currentSel; }

    public void paint(Graphic g){
      if(hasFocus){ Menu.centerS = "Select"; focus(g, x, y, width, height); }
       g.setFont(Utils.pmfont); g.setColor(0x000000);
       g.drawString(title+":", x+12, y, Graphic.TOP|Graphic.LEFT);
       g.drawGradient(0x202020, 0x2f2f2f, 0x232323, x+10, y+Utils.pmfh+2, width-20, cursorH, Graphic.VERTICAL);
       g.setColor(0xffffff); 
       g.drawString(coData[currentSel], x+15, y+Utils.pmfh+3, Graphic.TOP|Graphic.LEFT);
       g.drawGradient(0xdfdfdf, 0xeeeeee, 0xe2e2e2, x+width-40, y+Utils.pmfh+2, 30, cursorH, Graphic.VERTICAL);
       g.setColor(0x000000); g.drawRect(x+width-40, y+Utils.pmfh+2, 30, cursorH-1);
       g.fillTriangle(x+(width-40)+5, y+Utils.pmfh+6, x+(width-40)+25, y+Utils.pmfh+6, x+(width-40)+15, y+Utils.pmfh+cursorH-4);
       if(ss){ ss(g); }
    }
    private void ss(Graphic g){
      int ax = 10; int ay = 0;
      g.setColor(0xffffff); g.fillRect(x+5-2, y+Utils.pmfh, (width-ax)+4, ch);
      if(dataLen > 0){ g.setColor(0x000000); g.fillRect(x+5,y+CursorY+Utils.pmfh+2, width-ax, cursorH); }
      g.drawRect(x+5-2, y+Utils.pmfh, (width-ax)+3, ch-2);
      listY = 0;
      for(int i=printList; i<dataLen; i++){
         int colr = 0x000000;
         if(listY == CursorY) colr = 0xffffff;
         g.setFont(Utils.pmfont); g.setColor(colr);
         g.drawString(coData[i] , x+ax, y+(listY + Utils.pmfh+2)+2, 20);
         listY += cursorH;
         if(listY > (ch-2)) break;
      }
    }

    public int getPreferredWidth(){ return 0; }
    public int getPreferredHeight(){ return ch; }

   public void onResize(){
      if(ss){ ch = (5*cursorH); }
      if(!ss){ ch = (cursorH+2)*2; }
   }

    public void onClick(){
       Menu.showComponent(" ", "Ok", "Back");
       duplicationKeys = !duplicationKeys;
       ss = !ss;
    }

   public void keyPressed(int key, int action){
      if(duplicationKeys){
         if(key == UP){ Up(); }
         if(key == DOWN){ Down(); }
         if(key == Dup_SOFT_RIGHT){ onClick(); }
      }
   }

   private void Down(){
       if(coData.length > 0){
          if(currentSel == coData.length - 1){ CursorY = 0; currentSel = 0; printList = 0; }
          else if(currentSel >= (ch/2)/cursorH){
              if(CursorY >= currentSel*cursorH){ printList++; currentSel++; }
              else{ currentSel++; CursorY += cursorH; }
          } else{ CursorY += cursorH; currentSel++; } }
   }

   private void Up(){
       if(coData.length > 0){
          if(currentSel == 0){ currentSel = coData.length - 1;
          if(coData.length > (ch-2)/cursorH){ printList = (coData.length - (ch-2) / cursorH) + 2; CursorY = (coData.length - 1 - printList) * cursorH; }
          else{ CursorY = (coData.length - 1) * cursorH; }
          } else if((CursorY == 0) & (currentSel > 0)){ printList--; currentSel--; }
          else if(CursorY > 0){ CursorY -= cursorH; currentSel--; } }
   }


}