package j2me.ng.ui.paint;

import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;
import javax.microedition.lcdui.game.*;

public class GamePaint extends GameCanvas{
    public int W, H, currentMode;
    private Graphic graphic;
    public static int
            UP = -1,
            DOWN = -2,
            LEFT = -3,
            RIGHT = -4,
            CENTER = -5,
            SOFT_LEFT = -6,
            SOFT_RIGHT = -7,
            CALL = -10,
            KEY_POUND = 35,
            KEY_STAR = 42,
            KEY_NUM0 = 48,
            KEY_NUM1 = 49,
            KEY_NUM2 = 50,
            KEY_NUM3 = 51,
            KEY_NUM4 = 52,
            KEY_NUM5 = 53,
            KEY_NUM6 = 54,
            KEY_NUM7 = 55,
            KEY_NUM8 = 56,
            KEY_NUM9 = 57;

    public GamePaint(){
       super(false);
       setFullScreenMode(true);
       W = getWidth();
       H = getHeight();
    }

    public GamePaint(boolean suppressKeyEvents){
       super(suppressKeyEvents);
    }

    protected Graphic getGraphic(){
        graphic = new Graphic();
        return graphic;
    }

    public void setFullScreen(boolean screen){ setFullScreenMode(screen); }
    public int Width(){ return getWidth(); }
    public int Height(){ return getHeight(); }

    public Image getScreenSnap(){
       Image ss = Image.createImage(W, H);
       Graphics gra = ss.getGraphics();
       paint(gra);
       return ss;
    }

    public void paint(Graphics g){
        graphic = new Graphic(g);
        Paint(graphic);
    }
    public void Paint(Graphic g){ }

}