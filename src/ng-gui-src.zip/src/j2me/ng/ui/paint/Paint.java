package j2me.ng.ui.paint;

import j2me.ng.ui.*;
import javax.microedition.lcdui.Image;
import javax.microedition.lcdui.Canvas;
import javax.microedition.lcdui.Graphics;

public class Paint extends Canvas{
   public int W, H, currentMode;
   Graphic graphic;
   public final static int UP = 0;
   public final static int DOWN = 1;
   public final static int LEFT = 2;
   public final static int RIGHT = 3;
   public final static int KEY_NUM0 = 4;
   public final static int KEY_NUM1 = 5;
   public final static int KEY_NUM2 = 6;
   public final static int KEY_NUM3 = 7;
   public final static int KEY_NUM4 = 8;
   public final static int KEY_NUM5 = 9;
   public final static int KEY_NUM6 = 10;
   public final static int KEY_NUM7 = 11;
   public final static int KEY_NUM8 = 12;
   public final static int KEY_NUM9 = 13;
   public final static int KEY_STAR = 14;
   public final static int KEY_POUND = 15;
   public final static int CALL = 16;
   public final static int SOFT_LEFT  = 17;
   public final static int SOFT_RIGHT = 18;
   public final static int CENTER = 19;
   public final static int Dup = 20;
   public final static int Dup_SOFT_LEFT = 21;
   public final static int Dup_SOFT_RIGHT = 22;
   public final static int Dup_CENTER = 23;

    public Paint(){
       setFullScreenMode(true);
       W = getWidth();
       H = getHeight();
    }

    public void Paint(Graphic g){ }
    public void PaintSS(Graphic g){ }

    protected void paint(Graphics g){
     //   System.out.println("be Drawed");
       graphic = new Graphic(g);
       Paint(graphic);
    }

    protected Graphic getGraphic(){
        graphic = new Graphic();
        return graphic;
    }

    public Image getScreen(){
       Image ss = Image.createImage(W, H);
       Graphics gra = ss.getGraphics();
       paint(gra);
       return ss;
    }

    public Image getScreen(int width, int height){
       Image ss = Image.createImage(width, height);
       Graphics gra = ss.getGraphics();
       paint(gra);
       return ss;
    }

    public static String getKeyname(int key){
         switch(key){
            case Canvas.LEFT: return "LEFT";
            case Canvas.RIGHT: return "RIGHT";
            case Canvas.DOWN: return "DOWN";
            case Canvas.UP: return "UP";
            case Canvas.FIRE: return "CENTER";
            case Canvas.KEY_NUM0: return "0";
            case Canvas.KEY_NUM1: return "1";
            case Canvas.KEY_NUM2: return "2";
            case Canvas.KEY_NUM3: return "3";
            case Canvas.KEY_NUM4: return "4";
            case Canvas.KEY_NUM5: return "5";
            case Canvas.KEY_NUM6: return "6";
            case Canvas.KEY_NUM7: return "7";
            case Canvas.KEY_NUM8: return "8";
            case Canvas.KEY_NUM9: return "9";
            case Canvas.KEY_STAR: return "*";//Key STAR
            case Canvas.KEY_POUND: return "#";//Key POUND
            case -1: return "UP";
            case -2: return "DOWN";
            case -3: return "LEFT";
            case -4: return "RIGHT";
            case -5: return "CENTER";
            case -6: return "LEFT_SOFT";
            case -7: return "RIGHT_SOFT";
            case -10: return "CALL";
      }
      return "";
    }

    public static int getKey(int key){
         switch(key){
           case Canvas.LEFT: return LEFT;
           case Canvas.RIGHT: return RIGHT;
           case Canvas.DOWN: return DOWN;
           case Canvas.UP: return UP;
           case Canvas.FIRE: return CENTER;
           case Canvas.KEY_NUM0: return KEY_NUM0;
           case Canvas.KEY_NUM1: return KEY_NUM1;
           case Canvas.KEY_NUM2: return KEY_NUM2;
           case Canvas.KEY_NUM3: return KEY_NUM3;
           case Canvas.KEY_NUM4: return KEY_NUM4;
           case Canvas.KEY_NUM5: return KEY_NUM5;
           case Canvas.KEY_NUM6: return KEY_NUM6;
           case Canvas.KEY_NUM7: return KEY_NUM7;
           case Canvas.KEY_NUM8: return KEY_NUM8;
           case Canvas.KEY_NUM9: return KEY_NUM9;
           case Canvas.KEY_STAR: return KEY_STAR;
           case Canvas.KEY_POUND: return KEY_POUND;
           case -1: return UP;
           case -2: return DOWN;
           case -3: return LEFT;
           case -4: return RIGHT;
           case -5: return CENTER;
           case -6: return SOFT_LEFT;
           case -7: return changeKey(SOFT_RIGHT, Dup_SOFT_RIGHT);
           case -10: return CALL;
       }
      return 0;
    }

  static int changeKey(int orignalKey, int duplicateKey){
     int k = 0;
     if(Component.isDuplicationOfKeysOfNavigation()){ k = duplicateKey; }
     else{ k = orignalKey; }
     return k;
  }

}