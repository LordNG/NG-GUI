package j2me.ng.ui.paint;

import j2me.ng.ui.*;
import j2me.ng.ui.image.ImageUtil;
import j2me.ng.util.*;
import javax.microedition.lcdui.Font;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;

public class Graphic{
   public static final int VERTICAL = 0, HORIZONTAL = 1, DOUBLEVERTICAL = 2, DOUBLEHORIZONTAL = 3;//Gradient
   public static final int SOLID = 0, DOTTED = 1;//Stroke style
   public static final int HCENTER = 1, VCENTER = 2, LEFT = 4, RIGHT = 8, TOP = 16, BOTTOM = 32, BASELINE = 64;//Position
   public final static int UPLEFT=500,UPRIGHT=600,DOWNLEFT=700,DOWNRIGHT=800;//Shadows
   private Graphics graphics;

   public Graphic(){ }
   public Graphic(Graphics graphics){ this.graphics = graphics; }

    public int getClipX(){ return graphics.getClipX(); }
    public int getClipY(){ return graphics.getClipY(); }
    public int getClipWidth(){ return graphics.getClipWidth(); }
    public int getClipHeight(){ return graphics.getClipHeight(); }
    public int getDisplayColor(int color){ return graphics.getDisplayColor(color); }
    public int getColor(){ return graphics.getColor(); }
    public int getGrayScale(){ return graphics.getGrayScale(); }
    public int getRedComponent(){ return graphics.getRedComponent(); }
    public int getGreenComponent(){ return graphics.getGreenComponent(); }
    public int getBlueComponent(){ return graphics.getBlueComponent(); }
    public int getTranslateX(){ return graphics.getTranslateX(); }
    public int getTranslateY(){ return graphics.getTranslateY(); }
    public int getStrokeStyle(){ return graphics.getStrokeStyle(); }
    public Font getFont(){ return graphics.getFont(); }
    public void translate(int x, int y){ graphics.translate(x, y); }

    public void clipRect(int x, int y, int width, int height){ graphics.clipRect(x, y, width, height); }
    public void copyArea(int x_src, int y_src, int width, int height, int x_dest, int y_dest, int anchor){ graphics.copyArea(x_src, y_src, width, height, x_dest, y_dest, anchor); }
    public void drawChar(char character, int x, int y, int anchor){ graphics.drawChar(character, x, y, anchor); }
    public void drawChars(char[] data, int offset, int length, int x, int y, int anchor){ graphics.drawChars(data, offset, length, x, y, anchor); }
    public void drawPhoto(Photo photo, int x, int y, int anchor){ graphics.drawImage(photo.getImage(), x, y, anchor); }
    public void drawImage(Image image, int x, int y, int anchor){ graphics.drawImage(image, x, y, anchor); }
    public void drawRGB(int[] rgbData, int offset, int scanlength, int x, int y, int width, int height, boolean processAlpha){ graphics.drawRGB(rgbData, offset, scanlength, x, y, width, height, processAlpha); }
    public void drawRegion(Image src, int x_src, int y_src, int width, int height, int transform, int x_dest, int y_dest, int anchor){ graphics.drawRegion(src, x_src, y_src, width, height, transform, x_dest, y_dest, anchor); }
    public void drawString(String str, int x, int y, int anchor){ graphics.drawString(str, x, y, anchor); }
    public void drawSubstring(String str, int offset, int len, int x, int y, int anchor){ graphics.drawSubstring(str, offset, len, x, y, anchor); }
    public void drawArc(int x, int y, int width, int height, int startAngle, int arcAngle){ graphics.drawArc(x, y, width, height, startAngle, arcAngle); }
    public void drawPoint(int x, int y, int fat, boolean fill){
        if(fill == true) graphics.fillRect(x, y, fat, fat);
        if(fill == false) graphics.drawRect(x, y, fat, fat);
    }
    public void drawLine(int x1, int y1, int x2, int y2){ graphics.drawLine(x1, y1, x2, y2); }
    public void drawRect(int x, int y, int width, int height){ graphics.drawRect(x, y, width, height); }
    public void drawRoundRect(int x, int y, int width, int height, int arcWidth, int arcHeight){ graphics.drawRoundRect(x, y, width, height, arcWidth, arcHeight); }
    public void drawTriangle(int x1, int y1, int x2, int y2, int x3, int y3){ graphics.drawLine(x1, y1, x2, y2); graphics.drawLine(x2, y2, x3, y3); graphics.drawLine(x3, y3, x1, y1); }

    public void fillArc(int x, int y, int width, int height, int startAngle, int arcAngle){ graphics.fillArc(x, y, width, height, startAngle, arcAngle); }
    public void fillPoint(int x, int y, int fat){ graphics.fillRect(x, y, fat, fat); }
    public void fillRect(int x, int y, int width, int height){ graphics.fillRect(x, y, width, height); }
    public void fillRoundRect(int x, int y, int width, int height, int arcWidth, int arcHeight){ graphics.fillRoundRect(x, y, width, height, arcWidth, arcHeight); }
    public void fillTriangle(int x1, int y1, int x2, int y2, int x3, int y3){ graphics.fillTriangle(x1, y1, x2, y2, x3, y3); }

    public void setClip(int x, int y, int width, int height){ graphics.setClip(x, y, width, height); }
    public void setColor(int RGB){ graphics.setColor(RGB); }
    public void setColor(int red, int green, int blue){ graphics.setColor(red, green, blue); }
    public void setFont(Font font){ graphics.setFont(font); }
    public void setGrayScale(int value){ graphics.setGrayScale(value); }
    public void setStrokeStyle(int style){ graphics.setStrokeStyle(style); }

    public void drawRegion(Photo src, int x_src, int y_src, int width, int height, int transform, int x_dest, int y_dest, int anchor){
        graphics.drawRegion(src.getImage(), x_src, y_src, width, height, transform, x_dest, y_dest, anchor);
    }

    public int drawWrapString(String str, int x, int y, int width){
       Font font = graphics.getFont();
       graphics.setFont(font);
       Godawn lines = StringUtil.wrap(str, font, width);
       for(int i=0; i<lines.size(); i++){
           graphics.drawString((String)lines.elementAt(i), x, y+(i*font.getHeight()), Graphics.LEFT|Graphics.TOP);
       }
       return lines.size()*font.getHeight();
    }

//Shadow
    public void RectShadow(int x, int y, int w, int h, int color, int stroke){
          x = x-stroke;    y = y-stroke;
       Shadow(x+stroke, y, w, stroke, TOP, color);
       Shadow(x+stroke, h+y+stroke, w, stroke, BOTTOM, color);
       Shadow(x, y+stroke, stroke, h, LEFT, color);
       Shadow(w+x+stroke, y+stroke, stroke, h, RIGHT, color);
       Shadow(x, y, stroke, stroke, UPLEFT, color);
       Shadow(w+x+stroke, y, stroke, stroke, UPRIGHT, color);
       Shadow(x, h+y+stroke, stroke, stroke, DOWNLEFT, color);
       Shadow( w+x+stroke, h+y+stroke, stroke, stroke, DOWNRIGHT, color);
    }
    public void Shadow(int x, int y, int w, int h, int orientation, int color){
       if(orientation == UPLEFT){ for(int i=0; i<w; i++) graphics.drawImage(ImageUtil.createTransparentImage(w-i, h-i, color), x+i, y+i, 0); }
       if(orientation == UPRIGHT){ for(int i=0; i<w; i++) graphics.drawImage(ImageUtil.createTransparentImage(w-i, h-i, color), x, y+i, 0); }
       if(orientation == DOWNLEFT){ for(int i=0; i<w; i++) graphics.drawImage(ImageUtil.createTransparentImage(w-i, h-i, color), x+i, y, 0); }
       if(orientation == DOWNRIGHT){ for(int i=0; i<w; i++) graphics.drawImage(ImageUtil.createTransparentImage(w-i, h-i, color), x, y, 0); }
       if(orientation == TOP){ for(int i=0; i<h; i++) graphics.drawImage(ImageUtil.createTransparentImage(w, h-i, color), x, y+i, 0); }
       if(orientation == BOTTOM){ for(int i=0; i<h; i++) graphics.drawImage(ImageUtil.createTransparentImage(w, h-i, color), x, y, 0); }
       if(orientation == LEFT){ for(int i=0; i<w; i++) graphics.drawImage(ImageUtil.createTransparentImage(w-i, h, color), x+i, y, 0); }
       if(orientation == RIGHT){ for(int i=0; i<w; i++) graphics.drawImage(ImageUtil.createTransparentImage(w-i, h, color), x, y, 0); }
    }
//Shadow
//Gradient
    public void drawGradient(int color1, int color2, int x, int y, int w, int h, int orientation){
       int max = orientation == VERTICAL ? h : w;
       int color1RGB[] = new int[]{(color1>>16) & 0xff,(color1>>8) & 0xff,color1 & 0xff};
       int color2RGB[] = new int[]{(color2>>16) & 0xff,(color2>>8) & 0xff,color2 & 0xff};
       int colorCalc[] = new int[]{ ((color2RGB[0] - color1RGB[0])<<16)/max, ((color2RGB[1] - color1RGB[1])<<16)/max, ((color2RGB[2] - color1RGB[2])<<16)/max };
       for(int col = max; col > -1; col--){
          graphics.setColor( (color1RGB[0]+((col*colorCalc[0])>>16)) <<16 | (color1RGB[1]+((col*colorCalc[1])>>16)) <<8  | (color1RGB[2]+((col*colorCalc[2])>>16)) );
          if(orientation == VERTICAL){ graphics.drawLine(x, y + col, x + w - 1, y + col); }
          if(orientation == HORIZONTAL){ graphics.drawLine(x + col, y, x + col, y + h - 1); }
       }
    }
    public void drawGradient(int color1, int color2, int color3, int x, int y, int w, int h, int orientation){
       if(orientation == VERTICAL){ drawGradient(color1, color2, x, y, w, h/2, VERTICAL); drawGradient(color2, color3, x, y + h/2, w, h/2, VERTICAL); }
       if(orientation == HORIZONTAL){ drawGradient(color1, color2, x, y, w/2, h, HORIZONTAL); drawGradient(color2, color3, x + w/2, y, w/2, h, HORIZONTAL); }
    }
    public void RoundRectGradient(int color1, int color2, int x, int y, int w, int h, int orientation){//round: 8
       if(orientation == VERTICAL){ drawGradient(color1, color2, x+3, y, w-6, h, VERTICAL); drawGradient(color1, color2, x+1, y+1, w-2, h-2, VERTICAL); drawGradient(color1, color2, x, y+3, w, h-6, VERTICAL); }
       if(orientation == HORIZONTAL){ drawGradient(color1, color2, x+3, y, w-6, h, HORIZONTAL); drawGradient(color1, color2, x+1, y+1, w-2, h-2, HORIZONTAL); drawGradient(color1, color2, x, y+3, w, h-6, HORIZONTAL); }
    }
    public void RoundRectGradient(int color1, int color2, int color3, int x, int y, int w, int h, int orientation){//round: 8
       if(orientation == VERTICAL){ drawGradient(color1, color2, color3, x+3, y, w-6, h, VERTICAL); drawGradient(color1, color2, color3, x+1, y+1, w-2, h-2, VERTICAL); drawGradient(color1, color2, color3, x, y+3, w, h-6, VERTICAL); }
       if(orientation == HORIZONTAL){ drawGradient(color1, color2, color3, x+3, y, w-6, h, HORIZONTAL); drawGradient(color1, color2, color3, x+1, y+1, w-2, h-2, HORIZONTAL); drawGradient(color1, color2, color3, x, y+3, w, h-6, HORIZONTAL); }
    }
//Gradient

   public void drawStatusbar(String title, int x, int y, int align){
     Font font = graphics.getFont();
     int w = graphics.getClipWidth();
      drawGradient(0x000000, 0x2f2f2f, 0, y, w, font.getHeight()+2, Graphic.VERTICAL);
      graphics.setColor(0xffffff);
      graphics.drawString(title, w/2, 0, Graphic.HCENTER|align);
      Shadow(0, font.getHeight()+2, w, 5, Graphic.BOTTOM, 0x1f000000);
      graphics.setColor(0x555555); graphics.drawLine(0, y+font.getHeight()+2, w, y+font.getHeight()+2);
   }
   public void drawSoftbar(String left, String center, String right,int x, int y, int align){
     Font font = graphics.getFont();
     int w = graphics.getClipWidth();
      drawGradient(0x2f2f2f, 0x000000, x-x, y-font.getHeight()-2, w, font.getHeight()+2, Graphic.VERTICAL);
      graphics.setColor(0xffffff);
      graphics.drawString(left, x-x+1, y, Graphic.LEFT|align);
      graphics.drawString(center, x/2, y, Graphic.HCENTER|align);
      graphics.drawString(right, x-1, y, Graphic.RIGHT|align);
   //   Shadow(0, y-font.getHeight()-1-5, w, 5, Graphic.TOP, 0x1f000000);
      graphics.setColor(0x555555); graphics.drawLine(x-x, y-font.getHeight()-2, w, y-font.getHeight()-2);
   }

}