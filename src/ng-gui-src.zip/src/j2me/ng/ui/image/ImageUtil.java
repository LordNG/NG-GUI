package j2me.ng.ui.image;

import javax.microedition.lcdui.Image;
import javax.microedition.lcdui.Graphics;

public class ImageUtil{

  public ImageUtil(){ }

  private static int[] rescaleArray(int rgb[], int w, int h, int rw, int rh){
      int rgb1[] = new int[rw * rh];
      for(int w1 = 0; w1 < rh; w1++){ int h1 = (w1 * h) / rh;
      for(int rw1 = 0; rw1 < rw; rw1++){ int rh1 = (rw1 * w) / rw;
      rgb1[rw * w1 + rw1] = rgb[w * h1 + rh1]; }
   } return rgb1;
 }

  public static Image ResizeImage(Image image, int w, int h) {
    int rgb[] = new int[image.getWidth() * image.getHeight()];
    image.getRGB(rgb, 0, image.getWidth(), 0, 0, image.getWidth(), image.getHeight());
    int rgb1[] = rescaleArray(rgb, image.getWidth(), image.getHeight(), w, h);
    Image image1 = Image.createRGBImage(rgb1, w, h, true);
    return image1;
 }

  public static Image CutImage(Image img, int x, int y, int w, int h) {
    int rgb[] = new int[w * h];
    img.getRGB(rgb, 0, w, x, y, w, h);
    Image image = Image.createRGBImage(rgb, w, h, true);
    return image;
 }

  public static Image changeColor(Image source, int fromColor, int toColor) {
   int iw = source.getWidth ();
   int ih = source.getHeight () ;
   int [] rgb = new int [ iw * ih ] ;
   int deviceColor = getDeviceColor(fromColor);
  source.getRGB(rgb, 0, iw, 0, 0, iw, ih ) ;
   for (int i = 0 ; i < rgb.length ; i ++ ) {
   if (rgb [ i] == deviceColor) {
    rgb [ i] = toColor | (0xFF << 24 ); }
 } return Image.createRGBImage(rgb, iw, ih, true) ;
 }

   public static int getDeviceColor(int color){
     Image fake = Image.createRGBImage (new int []{ color }, 1, 1 , false);
     int [] rgb = new int [ 1];
     fake.getRGB ( rgb, 0, 1, 0 , 0 , 1, 1) ;
     return rgb [ 0];
   }

   public static Image reflectImage(Image image, int reflectionHeight){
     int w = image.getWidth();
     int h = image.getHeight();
     Image reflectedImage = Image.createImage(w, h + reflectionHeight);
     Graphics g = reflectedImage.getGraphics();
     g.drawImage(image, 0, 0, Graphics.TOP | Graphics.LEFT);
     int[] rgba = new int[w];
     int currentY = -1;
     for(int i = 0; i < reflectionHeight; i++){
     int y = (h - 1) - (i * h / reflectionHeight);
     if(y != currentY)
     image.getRGB(rgba, 0, w, 0, y, w, 1);
     int alpha = 0xff - (i * 0xff / reflectionHeight);
     for(int j = 0; j < w; j++){
     int origAlpha = (rgba[j] >> 24);
     int newAlpha = (alpha & origAlpha) * alpha / 0xff;
     rgba[j] = (rgba[j] & 0x00ffffff);
     rgba[j] = (rgba[j] | (newAlpha << 24));
     }
     g.drawRGB(rgba, 0, w, 0, h + i, w, 1, true);
     }
    return reflectedImage;
  }

   public static Image createTransparentImage(int w, int h, int color) {
      Image image = Image.createImage(w, h);
      int[] rgb = new int [image.getWidth() * image.getHeight()];
      image.getRGB(rgb, 0, image.getWidth(), 0, 0, image.getWidth(), image.getHeight());
      for(int i=0; i<rgb.length; ++i){ if(rgb[i] == 0xffffffff){ rgb[i] &= color; } }
      return Image.createRGBImage(rgb, image.getWidth(), image.getHeight(), true);
   }

   public static Image blankImage(int w, int h){
      Image image = Image.createImage(w, h);
      Graphics g = image.getGraphics();
      // convert image pixels data to int array
      int[] rgb = new int [image.getWidth() * image.getHeight()];
      image.getRGB(rgb, 0, image.getWidth(), 0, 0, image.getWidth(), image.getHeight());
      // drop alpha component (make it transparent) on pixels that are still at default color
      for(int i = 0; i < rgb.length; ++i){
          if(rgb[i] == 0xffffffff){ rgb[i] &= 0x00ffffff; }
      }
      // create a new image with the pixel data and set process alpha flag to true
      return Image.createRGBImage(rgb, image.getWidth(), image.getHeight(), true);
   }

}