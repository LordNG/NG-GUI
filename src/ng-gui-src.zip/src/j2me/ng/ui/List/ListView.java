package j2me.ng.ui.List;

import j2me.ng.ui.*;
import j2me.ng.ui.paint.*;
import j2me.ng.util.Utils;
import javax.microedition.lcdui.Image;

public class ListView extends DeviceScreen{
   public String listNull;
   private String[] listData;
   private Image[] imgData;
   private int currentSel, dataLen, imgLen, listY, CursorY,  printList, listl;

   public ListView(String titles, String[] stringElements, Image[] imageElements){
        title = titles;
        listData = stringElements;
        imgData = imageElements;
        dataLen = listData.length;
        if(imgData != null){ imgLen = imgData.length; }
        listl = Utils.pmfh+6;
        listY = CursorY = printList = currentSel = 0;
   }

   public void paintScreen(Graphic g, int x, int y){
      int ii = 0;
  //    if(dataLen > 0){ g.setColor(0x000000); g.fillRect(0, y+CursorY+pmfh+4, W-5, listl); }
      if(dataLen > 0){ g.drawGradient( 0x3f3f3f, 0x000000, 0x2f2f2f, 0, y+CursorY+Utils.pmfh+4, W, listl, Graphic.VERTICAL); }
      listY = 0;
      for(int i=printList; i<dataLen; i++){
         int colr = 0x000000;
         if(listY == CursorY) colr = 0xffffff;
         g.setFont(Utils.pmfont); g.setColor(colr);
         if(imgData != null || imgLen == dataLen){
            for(int j=0; j<imgLen; j++){
                g.drawImage(imgData[0] , x, y+(listY + Utils.pmfh+4)+2, 0);
                int xi = (imgData[0]).getWidth();
                g.drawString(listData[i] , x+xi, y+(listY + Utils.pmfh+4)+2, 20);
            }
         }
         else{ g.drawString(listData[i] , x, y+(listY + Utils.pmfh+4)+2, 20); }
         ii = listl*i; listY += listl;
         if(listY>(H - (Utils.pmfh+4*2)-3)) break;
      }
   }

   public void realpaint(Graphic g){
     I = Photo.createPhoto(W, H);
     Graphic G = I.getGraphic();
     drawBackground(G);
     paintScreen(G, 10, 0);
     g.drawPhoto(I, 0, 0, 0);
     drawFrame(g);
   }

    private void listDown() {
       if(listData.length > 0){
          if(currentSel == listData.length - 1){ CursorY = 0; currentSel = 0; printList = 0; }
          else if(currentSel > (H - (Utils.pmfh+4)) / listl - 6){
              if(CursorY >= H - (Utils.pmfh+4) - 4 * listl){ printList++; currentSel++; }
              else{ currentSel++; CursorY += listl; }
          } else{ CursorY += listl; currentSel++; } }
    }

    private void listUp() {
       if(listData.length > 0){
          if(currentSel == 0){ currentSel = listData.length - 1;
          if(listData.length > (H-((Utils.pmfh*2)+2))/listl){ printList = (listData.length - (H - ((Utils.pmfh*2)+2)) / listl) + 2; CursorY = (listData.length - 1 - printList) * listl; }
          else{ CursorY = (listData.length - 1) * listl; }
          } else if((CursorY == 0) & (currentSel > 0)){ printList--; currentSel--; }
          else if(CursorY > 0){ CursorY -= listl; currentSel--; } }
    }

    public String getSelected(){ return listData[currentSel]; }

    public int getSelectedIndex(){ return currentSel; }

    public void Paint(Graphic g){
      realpaint(g);
      if(currentMode == STATE_POPUP){ popup.popup(g, 10, 30, W, H); }
      repaint();
    }
/*
    public void keyPressed(int key) {
       int ke = getKey(key);
       System.out.println("KEY: "+key+", getKey("+ke+")");
//Menu
       if(currentMode == STATE_MENU){
          if(ke == SOFT_RIGHT){ showMenu(false); }
          else if(ke == RIGHT){
          if(commandListener != null) commandListener.commandAction((Command)cmdl.elementAt(menuFocus), this);
             showMenu(false);
          }
          else if(ke == UP){
              menuFocus--;
              if(menuFocus < 0) menuFocus = cmdl.length()-1;
          }
          else if(ke == DOWN){
              menuFocus++;
              if(menuFocus >= cmdl.length()) menuFocus = 0;
          }
          else if(ke == CENTER){
              if(commandListener != null) commandListener.commandAction((Command)cmdl.elementAt(menuFocus), this);
              showMenu(false);
          }
       }
//Menu > Main
       else if(currentMode == STATE_NORMAL){
          if(ke == SOFT_LEFT){//if(key == SOFT_LEFT)
             if(!cmdl.isEmpty()){
               if(cmdl.length() >= 1){ showMenu (true); }
               else{ commandListener.commandAction((Command)cmdl.elementAt(0), this); }
             }
             else{ }
          }
          else if(ke == UP){ listUp(); }
          else if(ke == DOWN){ listDown(); }
          else if(ke == CENTER){
             if(!cmdc.isEmpty()){ commandListener.commandAction((Command)cmdc.elementAt(0), this); }
             else{ }
          }
          else if(ke == SOFT_RIGHT){
              if(!cmdr.isEmpty()){ commandListener.commandAction((Command)cmdr.elementAt(0), this); }
              else{ }
          }
          if(ke == CALL){ if(!call.isEmpty()){ keyListener.keyAction((Key)call.elementAt(0), this); } else{ } }
          if(ke == KEY_NUM0){ if(!key0.isEmpty()){ keyListener.keyAction((Key)key0.elementAt(0), this); } else{ } }
          if(ke == KEY_STAR){ if(!star.isEmpty()){ keyListener.keyAction((Key)star.elementAt(0), this); } else{ } }
          if(ke == KEY_POUND){ if(!pound.isEmpty()){ keyListener.keyAction((Key)pound.elementAt(0), this); } else{ } }
       }
//Main > Popup
       else if(currentMode == STATE_POPUP){
          if(ke == SOFT_LEFT){ }
          else if(ke == CENTER){ }
          else if(ke == SOFT_RIGHT){ showPopup(false); }
       }
//Popup
    }*/
    public void keyPressed(int key) {
       int ke = getKey(key);
       System.out.println("KEY: "+key+", getKey("+ke+")");
       keyCommon(ke);
       if(currentMode == STATE_NORMAL){
          if(ke == UP){ listUp(); }
          else if(ke == DOWN){ listDown(); }
       }
    }
    public void keyRepeated(int key){ keyPressed(key); }
    public void keyReleased(int key){ }


}