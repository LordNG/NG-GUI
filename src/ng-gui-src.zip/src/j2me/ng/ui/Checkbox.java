package j2me.ng.ui;

import j2me.ng.ui.paint.Graphic;
import j2me.ng.util.Utils;
import java.io.IOException;
import javax.microedition.lcdui.Image;

public class Checkbox extends Component{
    public boolean checked = false;
    int type;
    Image checkbox, checkboxs, radiobox, radioboxs, img = null;
    String s;
    public static int CheckList = 0, RadioList = 1;

    void c(){
       try{
         checkbox = Image.createImage("/res/cb1.png");
         checkboxs = Image.createImage("/res/cb2.png"); }
       catch(IOException ex){ Errors.error("Unable to load image.", ex.toString(), true); }
       if(checked){ img = checkboxs; }
       if(!checked){ img = checkbox; }
    }
    void r(){
       try{
         radiobox = Image.createImage("/res/rb1.png");
         radioboxs = Image.createImage("/res/rb2.png"); }
       catch(IOException ex){ Errors.error("Unable to load image.", ex.toString(), true); }
    }

    public Checkbox(String s){
        this.s = s;
        type = CheckList;
       if(type == CheckList) c();
       if(type == RadioList) r();
    }

    public Checkbox(String s, boolean checked){
        this.s = s;
        this.checked = checked;
        type = CheckList;
       if(type == CheckList) c();
       if(type == RadioList) r();
    }

    public void paint(Graphic g){
      if(hasFocus){
        if(checked){ Menu.centerS = "Uncheck"; }
        if(!checked){ Menu.centerS = "Check"; }
        focus(g, x, y, width, height);
      }
        g.setColor(0x000000);
        g.setFont(Utils.pmfont);
        g.drawImage(img, x+10, y+1, 0);
        g.drawString(s, x+img.getWidth()+10+2, y+2, Graphic.LEFT | Graphic.TOP);
    //    g.drawRect(x+10, y+2, pmfh, pmfh);
    //    if(checked){ g.drawLine(x+10, y+2, x+10+pmfh, y+2+pmfh);  g.drawLine(x+10+pmfh, y+2, x+10, y+2+pmfh); }
    }

    public int getPreferredWidth(){
        return Utils.pmfont.stringWidth(s)+4;
    }

    public int getPreferredHeight(){
        return img.getHeight()+3;
    }

    public void onClick(){
       checked = !checked;
      if(type == CheckList){
        if(checked){ img = checkboxs; }
        if(!checked){ img = checkbox; }
      }
      if(type == RadioList){
       if(checked){ img = radioboxs; }
       if(!checked){ img = radiobox; }
      }
    }

    public boolean isChecked(){
       return checked;
    }


}