package j2me.ng.ui;

import j2me.ng.ui.paint.*;
import j2me.ng.util.Utils;

public class Gauge extends Component{
   public int maxvalue, value, gaugeH, percentage;
   public String Label;
   public int drawValue;//drawMaxValue = W-20, 
   private int textcol = 0x9f9f9f;

   public Gauge(String label, int maxValue, int Value){
     Label = label;
     gaugeH = Utils.bsfh+2;
     this.maxvalue = maxValue;
     this.value = Value;
   }

   void Less(int less){
       value = value-less;
     if(value <= 0){ value = 0; }
   }
   void Add(int add){
       value = value+add;
     if(value >= maxvalue){ value = maxvalue; }
   }
   void Percent(int percent){
 //     value = (getMaxValue()/percent);
   }

   public int getValue(){
     return value; }

   public int getMaxValue(){
     return maxvalue;}

   public int getPecentageValue(){
     percentage = (getValue()*100)/getMaxValue();
     return percentage; }

    public void paint(Graphic g){
      String val = ""+getValue();
      if(hasFocus){
        textcol = 0xff6f00;
        Menu.centerS = "Select";
        focus(g, x, y, width, height);
        val = "<"+getValue()+"("+getPecentageValue()+"% )"+">";
      }
      else textcol = 0x9f9f9f;
       int drawMaxValue = width-20;
       drawValue = (value*drawMaxValue)/maxvalue;
       g.setColor(0x000000); g.setFont(Utils.pmfont);
       g.drawString(Label+":", x+10, y, 0);
       g.drawGradient(0x202020, 0x2f2f2f, 0x232323, x+10, y+Utils.pmfh+2, drawMaxValue, gaugeH, Graphic.VERTICAL);
       g.drawGradient(0xe0e0e0, 0xe9e9e9, 0xe2e2e2, x+10, y+Utils.pmfh+2, drawValue, gaugeH, Graphic.VERTICAL);
       g.setColor(textcol); g.setFont(Utils.bsfont);
       g.drawString(val, W/2, y+Utils.pmfh+2, Graphic.TOP|Graphic.HCENTER);
       g.setColor(0x000000); g.drawRect( x+10-1, y+Utils.pmfh+1, drawMaxValue+1, gaugeH+1);
       g.setColor(0x000000);
       g.drawString("0", x+10-2, y+Utils.pmfh+2+gaugeH, Graphic.TOP|Graphic.LEFT);
       g.drawString(getMaxValue()+" ", x+20+drawMaxValue, y+Utils.pmfh+2+gaugeH, Graphic.TOP|Graphic.RIGHT);
    }

   public void keyPressed(int key, int action){
    if(duplicationKeys){
       if(key == LEFT){ Less(1); }
       if(key == RIGHT){ Add(1); }
       if(key == UP){ Add(5); }
       if(key == DOWN){ Less(5); }
      if(key == KEY_NUM1){ Percent(10); }
      if(key == KEY_NUM2){ Percent(20); }
      if(key == KEY_NUM3){ Percent(30); }
      if(key == KEY_NUM4){ Percent(40); }
      if(key == KEY_NUM5){ Percent(50); }
      if(key == KEY_NUM6){ Percent(60); }
      if(key == KEY_NUM7){ Percent(70); }
      if(key == KEY_NUM8){ Percent(80); }
      if(key == KEY_NUM9){ Percent(90); }
      if(key == KEY_NUM0){ Percent(0); }
    }
   }

    public void onClick(){
       Menu.showComponent(" ", "Ok", " ");
       duplicationKeys = !duplicationKeys;
    }

    public int getPreferredWidth(){
       return 0;
    }

    public int getPreferredHeight(){
       return (Utils.pmfh*2)+gaugeH+2;
    }

}