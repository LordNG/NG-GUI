package j2me.ng.ui;

import j2me.ng.app.Application;
import j2me.ng.ui.paint.Graphic;
import j2me.ng.util.Utils;

public class Alert extends DeviceScreen implements CommandListener{
    public static final int ALERT = 0, ALARM = 1, ERROR = 2, CONFIRMATION = 3, WARNING = 4, FOREVER = -2;
    public final Command DISMISS_COMMAND = new Command("Back", Command.EXIT);
    private String string;
    private int time = 0, alertType = ALERT;

    public Alert(String title, String string, int alerttype){
        this.title = title;
        this.string = string;
        alertType = alerttype;
        addCommand(DISMISS_COMMAND);
        setCommandListener(this);
        time = getDefaultTimeout(); 
    //    if(alertType != FOREVER){ Application.application.setView(this); }
    //    else{ Application.application.setView(time, this); }
    }

    public Alert(String title, String string, int time, int alerttype){
        this(title, string, alerttype);
        this.time = time;
        if(time <= 0){ this.time = getDefaultTimeout(); }
    }

    final int getDefaultTimeout(){ return 1000; }
    public final int getTimeout(){ return time; }
    public final int getAlertType(){ return alertType; }
    public String getString(){ return string; }

    public void setString(String string){ this.string = string; }
    public void setTimeout(int time){ this.time = time; }

   public void Paint(Graphic g){
      drawBackground(g);
      g.setColor(0x000000); g.setFont(Utils.pmfont);
      g.drawWrapString(string, 10, Utils.pmfh+2, W-20);
      drawFrame(g);
      repaint();
   }

    public void commandAction(Command cmd, DeviceScreen ds){
       if(cmd == DISMISS_COMMAND){ Application.application.setPreviousView(); }
    }

    public void keyPressed(int key){
       int ke = getKey(key);
       if(ke == SOFT_LEFT){//if(key == SOFT_LEFT)
          if(!cmdl.isEmpty()){
            if(cmdl.length() >= 1){ showMenu (true); }
            else{ commandListener.commandAction((Command)cmdl.elementAt(0), this); }
          }
          else{ }
       }
       else if(ke == CENTER){
          if(!cmdc.isEmpty()){ commandListener.commandAction((Command)cmdc.elementAt(0), this); }
          else{ }
       }
       else if(ke == SOFT_RIGHT){
          if(!cmdr.isEmpty()){ commandListener.commandAction((Command)cmdr.elementAt(0), this); }
          else{ }
       }
//Main
//Key - KeyListener
       if(ke == CALL){ if(!call.isEmpty()){ keyListener.keyAction((Key)call.elementAt(0), this); } else{ } }
       if(ke == KEY_NUM0){ if(!key0.isEmpty()){ keyListener.keyAction((Key)key0.elementAt(0), this); } else{ } }
       if(ke == KEY_STAR){ if(!star.isEmpty()){ keyListener.keyAction((Key)star.elementAt(0), this); } else{ } }
       if(ke == KEY_POUND){ if(!pound.isEmpty()){ keyListener.keyAction((Key)pound.elementAt(0), this); } else{ } }
//Key - KeyListener
    }
    public void keyRepeated(int key){ keyPressed(key); }
    public void keyReleased(int key){ }
}