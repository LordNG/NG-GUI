package j2me.ng.ui;

import j2me.ng.ui.paint.Graphic;
import j2me.ng.util.Utils;

public class Text extends Component{
    private String string;
    int h;

    public Text(String orignal){
       string = orignal;
    }

    public String getString(){
        return string;
    }

    public void paint(Graphic g){
      if(hasFocus){ Menu.centerS = "default";  focusl(g, x, y, width, height); }
       g.setColor(0x000000); g.setFont(Utils.pmfont);
       h = g.drawWrapString(string, x+10, y+2, width-20);
    }

    public int getPreferredWidth(){
       return 0;
    }

    public int getPreferredHeight(){
       return h+5;
    }

}