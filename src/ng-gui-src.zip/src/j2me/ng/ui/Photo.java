package j2me.ng.ui;

import java.io.*;
import j2me.ng.ui.paint.Graphic;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;

public class Photo extends Component{
 //   private Graphic graphic;
    private Image img;
    private int position = Graphic.LEFT;

    public Photo(Image image){ img = image; }
  //  public Photo(Graphic graphic, Image image){ this.graphic = graphic; img = image; }

    public Image getImage(){ return img; }

    public Graphic getGraphic(){ return new Graphic(img.getGraphics()); }

    public static Photo createPhoto(int width, int height){
        Image img = Image.createImage(width, height);
    //    Graphic gk = new Graphic(img.getGraphics());
    //    return new Photo(gk, img);
        return new Photo(img);
    }
    public static Photo createPhoto(Photo iimk){ return new Photo(Image.createImage(iimk.img)); }
    public static Photo createPhoto(String sname) throws IOException{ return new Photo(Image.createImage(sname)); }
    public static Photo createPhoto(byte[] data,int off,int len){ return new Photo(Image.createImage(data,off,len)); }
    public static Photo createPhoto(Photo iimk,int x,int y,int w,int h,int t){ return new Photo(Image.createImage(iimk.img,x,y,w,h,t)); }

    public static Photo createPhoto(InputStream is){
       try{ return new Photo(Image.createImage(is)); }
       catch(IOException e){ Errors.error("Unable to load photo"+is, e.toString(), true); }
       return null;
    }

    public static Photo createTransparentPhoto(int w, int h, int color){//0xff000000;"ff" level for Transparency
       Image img = Image.createImage(w, h);
       Graphics g = img.getGraphics();
       int[] rgb = new int [img.getWidth() * img.getHeight()];
       img.getRGB(rgb, 0, img.getWidth(), 0, 0, img.getWidth(), img.getHeight());
       for(int i=0; i<rgb.length; ++i){ if(rgb[i] == 0xffffffff){ rgb[i] &= color; } }
       return createRGBPhoto(rgb, img.getWidth(), img.getHeight(), true);
    }

    public static Photo createRGBPhoto(int[]rgb,int w,int h,boolean pAlpha){ return new Photo(Image.createRGBImage(rgb,w,h,pAlpha)); }

    public void getRGB(int[] arg0, int arg1, int arg2, int arg3, int arg4, int arg5, int arg6){ img.getRGB(arg0, arg1, arg2, arg3, arg4, arg5, arg6); }

    public int getImageWidth(){ return img.getWidth(); }
    public int getImageHeight(){ return img.getHeight(); }

    public boolean isMutable(){ return img.isMutable(); }

    public void setPosition(int anchor){ position = anchor; }

    public void paint(Graphic g){
      if(hasFocus){ Menu.centerS = "default";// focus(g, x, y, width, height);
        if(position == LEFT){ focus(g, x-1, y, getImage().getWidth()+2, getImage().getHeight()); }
        if(position == CENTER){ focus(g, ((width-getImage().getWidth())/2)-1, y, getImage().getWidth()+2, getImage().getHeight()); }
        if(position == RIGHT){ focus(g, (width-getImage().getWidth())-1, y, getImage().getWidth()+2, getImage().getHeight()); }
    
      }// g.drawPhoto(new Photo(img), x, y, 0);
      if(position == LEFT){ g.drawImage(getImage(), x, y, Graphic.TOP|Graphic.LEFT); }
      if(position == CENTER){ g.drawImage(getImage(), width/2, y, Graphic.TOP|Graphic.HCENTER); }
      if(position == RIGHT){ g.drawImage(getImage(), width, y, Graphic.TOP|Graphic.RIGHT); }
    }

    public int getPreferredWidth(){ return getImage().getWidth(); }
    public int getPreferredHeight(){ return getImage().getHeight(); }

}