package j2me.ng.ui;

import j2me.ng.util.*;
import j2me.ng.ui.paint.*;

public class DeviceScreen extends Menu{
    public CommandListener commandListener = null;
    public KeyListener keyListener = null;
    public String title;
    public Godawn components;
    public Component selection = null;
    public Photo I, photo;
    int cursor = 0;
    int cury = 0, curY = 0;
    int offset = 1;
    public Popup popup;

    public DeviceScreen(){ components = new Godawn(); }

    public final void setCommandListener(CommandListener commandlistener){ commandListener = commandlistener; }
    public final void setKeyListener(KeyListener keylistener){ keyListener = keylistener; }

    public int headerHeight(){ return title==null ? 0 : Utils.pmfh+5; }
    public int footerHeight(){ return Utils.psfh+5; }

    public void appendLayout(){
       cury = headerHeight()+offset;
       for(int i=0; i<components.size(); i++){
          Component e = ((Component)components.elementAt(i));
          e.x = 0; e.y = cury;
          e.width = getWidth();
          e.height = e.getPreferredHeight();
          e.onResize();
          cury += e.height;
          cury += offset;
       }
    }

    void focusUp(){
      if(selection != null){ if(!selection.switchUp()) return; }
      setFocus(cursor-1);
    }
    void focusDown(){
      if(selection != null){ if(!selection.switchDown()) return; }
      setFocus(cursor+1);
    }
    public void setFocus(int i){
      if(selection != null){ selection.focusLost(); selection.hasFocus = false; selection = null; }
      cursor = i; refocus();
    }
    public void refocus(){
       if((cursor <= 0)&&(!components.isEmpty())) cursor = 0;
       if(cursor >= components.size()) cursor = components.size()-1;
       if(cursor >= 0){
          selection = (Component)components.elementAt(cursor);
          selection.focusGained();
          selection.hasFocus = true;
          if(selection.y < curY) curY = selection.y-(headerHeight());
          if(selection.y+selection.height-curY > (H-headerHeight()-footerHeight())) curY = selection.y+selection.height - (H-headerHeight()-footerHeight());
       }
    }

    public void drawBackground(Graphic g){ g.drawGradient(0xbfefff, 0x8fcfff, 0x9fdffff, 0, 0, W, H, Graphic.VERTICAL); }

    public void drawFrame(Graphic g){
      g.setFont(Utils.pmfont); g.drawStatusbar(title, W, 0, Graphic.TOP);
   //   Clock(g, W, 0);
      drawMenu(g);
    }

   public void Clock(Graphic g, int x, int y){
     int cw = Utils.bsfont.stringWidth(Utils.getTime(":"))+2;
     g.setFont(Utils.bsfont); g.setColor(0xffffff);
     g.fillRoundRect(x-cw, y, cw, Utils.bsfh, 8, 8);
     g.setColor(0x000000); g.drawString(Utils.getTime(":"), x-cw+1, y, Graphic.TOP|Graphic.LEFT);
   }

   public void setPopup(Popup popup){ this.popup = popup; }
   public void showPopup(boolean condition){ showPopup(popup.getMenuL(), popup.getMenuC(), popup.getMenuR(), condition); }

   public void keyCommon(int ke){
//Menu
       if(currentMode == STATE_MENU){
          if(ke == SOFT_RIGHT){ showMenu(false); }
          else if(ke == RIGHT){
          if(commandListener != null) commandListener.commandAction((Command)cmdl.elementAt(menuFocus), this);
             showMenu(false);
          }
          else if(ke == UP){
              menuFocus--;
              if(menuFocus < 0) menuFocus = cmdl.length()-1;
          }
          else if(ke == DOWN){
              menuFocus++;
              if(menuFocus >= cmdl.length()) menuFocus = 0;
          }
          else if(ke == CENTER){
              if(commandListener != null) commandListener.commandAction((Command)cmdl.elementAt(menuFocus), this);
              showMenu(false);
          }
       }
//Menu > Main
       else if(currentMode == STATE_NORMAL){
          if(ke == SOFT_LEFT){//if(key == SOFT_LEFT)
             if(!cmdl.isEmpty()){
               if(cmdl.length() >= 1){ showMenu (true); }
               else{ commandListener.commandAction((Command)cmdl.elementAt(0), this); }
             }
             else{ }
          }
          else if(ke == CENTER){
             if(!cmdc.isEmpty()){ commandListener.commandAction((Command)cmdc.elementAt(0), this); }
             else{ }
          }
          else if(ke == SOFT_RIGHT){
              if(!cmdr.isEmpty()){ commandListener.commandAction((Command)cmdr.elementAt(0), this); }
              else{ }
          }
          if(ke == CALL){ if(!call.isEmpty()){ keyListener.keyAction((Key)call.elementAt(0), this); } else{ } }
          if(ke == KEY_NUM0){ if(!key0.isEmpty()){ keyListener.keyAction((Key)key0.elementAt(0), this); } else{ } }
          if(ke == KEY_STAR){ if(!star.isEmpty()){ keyListener.keyAction((Key)star.elementAt(0), this); } else{ } }
          if(ke == KEY_POUND){ if(!pound.isEmpty()){ keyListener.keyAction((Key)pound.elementAt(0), this); } else{ } }
       }
//Main > Popup
       else if(currentMode == STATE_POPUP){
          if(ke == SOFT_LEFT){ }
          else if(ke == CENTER){ }
          else if(ke == SOFT_RIGHT){ showPopup(false); }
       }
//Popup
    
   }


}