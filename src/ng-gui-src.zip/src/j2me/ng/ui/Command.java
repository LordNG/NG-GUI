package j2me.ng.ui;

public final class Command{
    public static final int
           MENU = 1,
           OK = 2,
           EXIT = 3,
           ITEM = 4;
    private String name;
    private int type;

 public Command(String name, int type){
    this.name = name;
    this.type = type;
 }

 public String getLabel(){
    return name;
 }

 public void setLabel(String name){
    this.name = name;
 }

 public int getCommandType(){
     return type;
 }

}