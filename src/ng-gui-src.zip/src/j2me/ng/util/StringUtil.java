package j2me.ng.util;

//import j2me.ng.ui.Font;
import j2me.ng.ui.paint.Graphic;
import javax.microedition.lcdui.Font;
import javax.microedition.lcdui.Graphics;

public class StringUtil{

   public StringUtil(){
   }

//WrapText
   public static Godawn wrap(String text, Font font, int width){
     Godawn result = new Godawn();
      if(text ==null) return result;
     boolean hasMore = true;
     int current = 0;// The current index of the cursor
     int lineBreak = -1;// The next line break index 
     int nextSpace = -1;// The space after line break
    while(hasMore){
        while(true){ lineBreak = nextSpace;
        if(lineBreak == text.length() - 1){ hasMore = false; break; }
        else{
            nextSpace = text.indexOf(' ', lineBreak+1);
            if(nextSpace == -1) nextSpace = text.length() -1;
            int linewidth = font.substringWidth(text, current, nextSpace-current);
            if(linewidth > width) break; }
        }
      String line = text.substring(current, lineBreak + 1);
      result.addElement(line);
      current = lineBreak + 1; }
    return result;
   }
 //WrapText
 //Wrap by Line
  public int wrapLines(Graphic g, String str, int x, int y){
     Godawn v = new Godawn();
     for(int ini=0,end=0;ini<str.length();ini=end+1){
         end=str.indexOf('\n',ini);
         if(end == -1) end=str.length();
         String st=str.substring(ini,end);
         if(st.length()>0) v.addElement(st);
     }
     String temp[]=new String[v.size()];
     v.copyInto(temp);
     int fh = g.getFont().getHeight();
     for(int i=0; i<temp.length; i++){
        g.drawString(temp[i], x, y+(i*fh), Graphics.LEFT|Graphics.TOP); }
     return temp.length;
  }
 //Wrap by Line

//Splitter
  public static String[] split(String s, char separator){
     Godawn v = new Godawn();
     for(int ini=0, end=0; ini<s.length(); ini=end+1){
         end=s.indexOf(separator,ini);
         if(end==-1) end=s.length();
         String st=s.substring(ini,end);
         if(st.length()>0) v.addElement(st);
     }
     String temp[]=new String[v.size()];
     v.copyInto(temp);
     return temp;
  }

  public static String[] split(String original, String separator){
     Godawn nodes = new Godawn();
     int index = original.indexOf(separator);// Parse nodes into vector
     while(index >= 0){
        nodes.addElement(original.substring(0, index));
        original = original.substring(index + separator.length());
        index = original.indexOf(separator);
     }
     nodes.addElement(original);// Get the last node
     String[] result = new String[nodes.size()];// Create splitted string array
     if(nodes.size() > 0){
       for(int loop = 0; loop < nodes.size(); loop++){ result[loop] = (String) nodes.elementAt(loop); }
     }
     return result;
  }
//Splitter

    public static String delSpace(String str){
       StringBuffer sb = new StringBuffer(str);
       for(int i=0; i<sb.length(); i++){
          if(sb.charAt(i) == ' '){ sb.deleteCharAt(i); }
       }
      return sb.toString();
    }

    public static Godawn toLines(String str){
       Godawn linev = new Godawn();
       for(int ini=0,end=0; ini<str.length(); ini=end+1){
          end = str.indexOf('\n', ini);
           if(end == -1) end = str.length();
          String st = str.substring(ini, end);
           if(st.length() == 0) linev.addElement("\n");
           if(st.length() > 0) linev.addElement(st);
       }
      return linev;
    }

    public static Godawn cutIt(String str, String End){
       Godawn linev = new Godawn();
       for(int ini=0,end=0; ini<str.length(); ini=end+1){
          end = str.indexOf(End, ini);
          if(end == -1) end = str.length();
          String st = str.substring(ini, end);
          if(st.length() > 0) linev.addElement(st);
       }
      return linev;
    }


}