package j2me.ng.util;

import java.util.*;
import javax.microedition.lcdui.Font;

public class Utils{

//Time
  public static String getTime(String dot){
    Calendar cal = Calendar.getInstance();
    cal.setTime(new Date());
    String hr = addZero(cal.get(Calendar.HOUR), 2);
    String mi = addZero(cal.get(Calendar.MINUTE), 2);
    String sec = addZero(cal.get(Calendar.SECOND), 2);
    String ms = addZero(cal.get(Calendar.MILLISECOND), 2);
    String ampm = " ";
     if(cal.get(Calendar.AM_PM) <= 0){ ampm = "am"; }
     if(cal.get(Calendar.AM_PM) >= 1){ ampm = "pm"; }
    String time = hr+dot+mi+dot+sec+" "+ampm;
    return time; }

  public static String addZero(int i, int size) {
     String sz = "00"+i;
     return sz.substring(sz.length()-size, sz.length());
  }
//Time

  public int RandomInt(int num){
     return (new Random().nextInt() >>> 1) % num; }

  public static int long2int(long l){
    int s = Integer.parseInt(String.valueOf(l));
    return s;
  }

 //Fonts
  public static final Font
     psfont = Font.getFont(64, 0, 8), pmfont = Font.getFont(64, 0, 0), plfont = Font.getFont(64, 0, 16),
     bsfont = Font.getFont(64, 1, 8), bmfont = Font.getFont(64, 1, 0), blfont = Font.getFont(64, 1, 16),
     isfont = Font.getFont(64, 2, 8), imfont = Font.getFont(64, 2, 0), ilfont = Font.getFont(64, 2, 16);
  public static final int
     psfh = psfont.getHeight(), pmfh = pmfont.getHeight(), plfh = plfont.getHeight(),
     bsfh = bsfont.getHeight(), bmfh = bmfont.getHeight(), blfh = blfont.getHeight(),
     isfh = isfont.getHeight(), imfh = imfont.getHeight(), ilfh = ilfont.getHeight();
 //end Fonts

}