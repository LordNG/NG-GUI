package j2me.ng.util;

public class Objects{

   public Objects(){
   }

   public static final boolean exist(Object[] objAr, Object obj) {
     if(obj != null){
        if(objAr != null){ int sz = objAr.length;
          if(sz > 0){ for(int i = 0; i < sz; i++){ if(objAr[i].equals(obj)){ return true; } } }
        }
      } return false;
   }

   public static final Object[] addElement(Object[] objAr, Object obj){
     if(obj != null){
        if(objAr != null){ int sz = objAr.length;
           Object[] objTmp = new Object[sz + 1];
           System.arraycopy(objAr, 0, objTmp, 0, sz);
           objTmp[sz] = obj;
           return objTmp; }
         else{
            objAr = new Object[1];
            objAr[0] = obj;
            return objAr; }
     } return null;
   }

   public static final Object[] removeElement(Object[] objAr, Object obj){
      if(objAr != null){ int sz = objAr.length;
         for(int i = 0; i < sz; i++){
             if(objAr[i].equals(obj)){ objAr = removeElement(objAr, i); break; }
         } return objAr; }
      return null;
   }

   public static final Object[] removeElement(Object[] objAr, int index){
      if(objAr != null){ int sz = objAr.length;
         if(index >= 0 && index < sz){ if(sz > 1){
            Object[] objTmp = new Object[sz - 1];
            int j = 0;
            for(int i = 0; i < sz; i++){  if(i == index){ continue; } objTmp[j] = objAr[i]; j++; }
            return objTmp; }
         }
      } return null;
   }


}