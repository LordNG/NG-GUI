package j2me.ng.util;

import java.util.*;

public class Godawn{
    Vector vector;

    public Godawn(){
       vector = new Vector();
    }

    public boolean contains(Object elem){
      return vector.contains(elem);
    }

    public boolean isEmpty(){
      return vector.isEmpty();
    }

    public boolean removeElement(Object obj){
      return vector.removeElement(obj);
    }

    public int capacity(){
      return vector.capacity();
    }

    public int indexOf(Object elem){
      return vector.indexOf(elem);
    }

    public int indexOf(Object elem, int index){
      return vector.indexOf(elem, index);
    }

    public int lastIndexOf(Object elem){
      return vector.lastIndexOf(elem);
    }

    public int lastIndexOf(Object elem, int index){
      return vector.lastIndexOf(elem, index);
    }

    public int size(){ return vector.size(); }
    public int length(){ return vector.size(); }

    public Object elementAt(int index){
      return vector.elementAt(index);
    }

    public Object firstElement(){
      return vector.firstElement();
    }

    public Object lastElement(){
      return vector.lastElement();
    }

    public String toString(){
      return vector.toString();
    }

    public Enumeration elements(){
      return vector.elements();
    }

    public void addElement(Object obj){
      vector.addElement(obj);
    }

    public void copyInto(Object[] anArray){
      vector.copyInto(anArray);
    }

    public void insertElementAt(Object obj, int index){
      vector.insertElementAt(obj, index);
    }

    public void removeAllElements(){
      vector.removeAllElements();
    }

    public void removeElementAt(int index){
      vector.removeElementAt(index);
    }

    public void setElementAt(Object obj, int index){
      vector.setElementAt(obj, index);
    }

    public static String[] toStringArray(Godawn godawn){
       String temp[] = new String[godawn.size()];
       godawn.copyInto(temp);
       return temp;
    }


}