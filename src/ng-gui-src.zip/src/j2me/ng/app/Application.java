package j2me.ng.app;

import j2me.ng.ui.*;
import j2me.ng.ui.transiton.Slider;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.Display;
import javax.microedition.midlet.MIDlet;

public abstract class Application extends MIDlet{
   private Display display;
   public static Application application;
   private static Displayable prevp, prev, current;

    public Application(){
      /*Clean up*/System.gc(); Runtime.getRuntime().gc();/*Any previously used memory*/
      display = javax.microedition.lcdui.Display.getDisplay(this);
      application = this;
      if(application == null){ Errors.error("Application error.", "j2me.ng.app.Application", true); }
    }

    public abstract void onStart();
    public abstract void onPause();
    public abstract void onDestroy(boolean un);
    public void killApplication(){ notifyDestroyed(); }
    public final String appProperty(String key){ return getAppProperty(key); }

    public void setView(Displayable displayable){
       prev = current;
       current = displayable;
       display.setCurrent(displayable);
    }
    public void setView(int forTime, Displayable d){
      setView(d);
      try{ Thread.sleep(forTime); }
      catch(InterruptedException ex){ Errors.error("System Error", ex.toString(), true); }
    }
    public void setPreviousView(){
      if(getPrevScreen() != null){
         display.setCurrent(getPrevScreen());
         prevp = prev;
         current = prev;
      }
       else{ System.out.print("Exit"); this.notifyDestroyed(); }
    }

    public void setSlideView(DeviceScreen screen, int direction , long duration){
       Slider slider = new Slider(display, screen, direction, duration);
       setView(slider);
    }

    public static Displayable getCurrentScreen(){ return current; }
    public static Displayable getPrevScreen(){ return prev; }
    public static Displayable getPrevPScreen(){ return prevp; }

    protected void startApp(){
      if(!Errors.get()){ onStart(); }
      if(Errors.get()){
         Alert alert = new Alert("Error", Errors.getError()+": "+ Errors.getMessage(), 3000, Alert.ERROR);
         Application.application.setView(alert.getTimeout(), alert);
         Application.application.setPreviousView();
      }
    }
    protected void pauseApp(){ onPause(); }
    protected void destroyApp(boolean un){ onDestroy(un); }

}