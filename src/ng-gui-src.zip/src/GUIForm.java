
import j2me.ng.ui.Form;
import j2me.ng.ui.transiton.Slider;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author LordPro
 */
public class GUIForm extends Form{

    public GUIForm(){
        super("Form");
    }

    /*
        form.append(tk);
        form.append(pho);
        form.append(pho1);
        form.append(cg);
        form.append(pho2);
    //    form.append(sp);
        form.append(ga);
        form.append(sw);
        form.append(swb);
        form.append(tf);
        form.append("just a String for this application for instance to use in the application. just a String for this application for instance to use in the application");
        form.append(ca);
        form.append(cb);
        form.append(cc);
        form.append(cd);
   //     form.append(rb);
        form.append(b);
        form.setPopup(pop);
        form.addCommand(cmd);
        form.addCommand(a);
        form.addCommand(ok);
        form.addCommand(exit);
        form.addKey(ka);
        form.setKeyListener(this);
        form.setCommandListener(this);
    }
    */
    
}
