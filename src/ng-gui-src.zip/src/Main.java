import j2me.ng.ui.*;
import j2me.ng.app.Application;
import j2me.ng.ui.List.*;
import j2me.ng.ui.transiton.Slider;
import java.io.IOException;

public class Main extends Application implements CommandListener, KeyListener{
   String str, s[];
   Command cmd, ok, exit, a, back;
   Alert alert;
   Gauge ga;
   Button lb, b;
   Checkbox ca, cb, cc, cd;
   ComboGroup cg;
   TextField tf, n, p;
   Ticker tk;
   Key ka;
   Form form, fgd;
   Space sp;
   Popup pop;
   ListView list;
   Radiobox rb;
   Switch sw, swb;
   Photo pho, pho1, pho2;

    public Main(){
       cmd = new Command("Command", Command.MENU);
       ok = new Command("Done", Command.OK);
       exit = new Command("Quit", Command.EXIT);
       back = new Command("Back", Command.EXIT);
       ka = new Key(Key.CALL);
       a = new Command("Form", Command.ITEM);
       ga = new Gauge("gauge", 100, 10);
       s = new String[]{"A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"};
       ca = new Checkbox("CB A", true);
       cc = new Checkbox("CB C");
       cd = new Checkbox("CB D");
       sw = new Switch("Switch");
       swb = new Switch("Switch B");
       cg = new ComboGroup("ComboGroup", s);
       tf = new TextField("TextField", "Ng", 100, TextField.ANY);
       tk = new Ticker("just a String for this application for instance to use in the application");
       b = new Button("Continue");
       n = new TextField("Username", "", 10, TextField.NUMERIC);
       p = new TextField("Password", "", 10, TextField.PASSWORD);
       cb = new Checkbox("Accept User Agreement", false);
       lb = new Button("Continue", "Dis-Agree");
       sp = new Space(240, 20);
       rb = new Radiobox("Radio Box eg", s);
       pop = new Popup("Popup Text", "ScreenShot saved sucessfully, This is a popup example for instance");
       pop.addMenuR("Back");
       try{
          pho = Photo.createPhoto("/res/n.png"); pho.setPosition(Photo.LEFT);
          pho1 = Photo.createPhoto("/res/n.png"); pho1.setPosition(Photo.CENTER);
          pho2 = Photo.createPhoto("/res/n.png"); pho2.setPosition(Photo.RIGHT);
       }
       catch(IOException ex) { }
    }

    void main(){
        form = new Form("Form");
        form.append(tk);
        form.append(pho);
        form.append(pho1);
        form.append(cg);
        form.append(pho2);
    //    form.append(sp);
        form.append(ga);
        form.append(sw);
        form.append(swb);
        form.append(tf);
        form.append("just a String for this application for instance to use in the application. just a String for this application for instance to use in the application");
        form.append(ca);
        form.append(cb);
        form.append(cc);
        form.append(cd);
   //     form.append(rb);
        form.append(b);
        form.setPopup(pop);
        form.addCommand(cmd);
        form.addCommand(a);
        form.addCommand(ok);
        form.addCommand(exit);
        form.addKey(ka);
        form.setKeyListener(this);
        form.setCommandListener(this);
        setSlideView(form, Slider.LEFT, 500);
    }

    void af(){
       fgd = new Form("Sign Up");
       fgd.append(n);
       fgd.append(p);
       fgd.append(cb);
       fgd.append(lb);
       fgd.addKey(ka);
       fgd.addCommand(back);
       fgd.setKeyListener(this);
       fgd.setCommandListener(this);
        setSlideView(fgd, Slider.RIGHT, 500);
    }

    void l(){
       list = new ListView("List ex", s, null);
       list.addCommand(back);
       list.addCommand(ok);
       list.addKey(ka);
       list.setKeyListener(this);
       list.setCommandListener(this);
        setSlideView(list, Slider.UP, 500);
    }

    public void onStart(){
      Splash splash = new Splash();
      setView(1000, splash);
      main();
    }

    public void onDestroy(boolean unconditional){ killApplication(); }
        
    public void onPause(){ }

    public void commandAction(Command command, DeviceScreen devicescreen){
       if(command == a){ af(); }
       if(command == cmd){ l(); }
       if(command == back){ main(); }
       if(command == exit){ onDestroy(true); }
       if(command == ok){
          if(devicescreen == list){
             alert = new Alert("Selected", "You have selected: "+list.getSelected()+" @ index "+list.getSelectedIndex()+".", Alert.ALERT);
             setView(alert);
         //    setPreviousView();
          }
       }
    }

    public void keyAction(Key key, DeviceScreen ds){
       if(key == ka){
         if(ds == form){  }
         if(ds == fgd){ }
         if(ds == list){ }
       }
    }

}